from typing import Dict, List, Any, Optional, Union
from datetime import datetime, timezone
import re
import json
import hashlib
from pathlib import Path

def format_timestamp(timestamp: Union[datetime, str, None]) -> str:
    """
    Format timestamp for display in the UI
    
    Args:
        timestamp: Datetime object, ISO string, or None
        
    Returns:
        Formatted timestamp string
    """
    if timestamp is None:
        return "N/A"
    
    if isinstance(timestamp, str):
        try:
            timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        except (ValueError, AttributeError):
            return str(timestamp)
    
    if not isinstance(timestamp, datetime):
        return "Invalid Date"
    
    try:
        # Format as: "Dec 15, 2023 14:30 UTC"
        if timestamp.tzinfo is None:
            # Assume UTC if no timezone info
            timestamp = timestamp.replace(tzinfo=timezone.utc)
        
        return timestamp.strftime("%b %d, %Y %H:%M %Z")
    except Exception:
        return str(timestamp)

def create_audit_trail(threads: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Create audit trail from processed threads
    
    Args:
        threads: Dictionary of thread data
        
    Returns:
        List of audit trail entries
    """
    audit_trail = []
    
    for thread_id, thread_data in threads.items():
        emails = thread_data.get('emails', [])
        
        # Create audit entry for thread creation
        audit_entry = {
            'event_id': generate_event_id(),
            'timestamp': datetime.now().isoformat(),
            'event_type': 'thread_reconstruction',
            'thread_id': thread_id,
            'details': {
                'email_count': len(emails),
                'participants': thread_data.get('participants', []),
                'time_span': calculate_thread_timespan(emails),
                'entities_extracted': sum(len(email.get('entities', [])) for email in emails),
                'summary_generated': bool(thread_data.get('summary'))
            },
            'compliance_status': 'compliant',
            'data_integrity_hash': generate_thread_hash(thread_data)
        }
        
        audit_trail.append(audit_entry)
        
        # Create audit entries for each email in thread
        for email_idx, email in enumerate(emails):
            email_audit = {
                'event_id': generate_event_id(),
                'timestamp': datetime.now().isoformat(),
                'event_type': 'email_processing',
                'thread_id': thread_id,
                'email_index': email_idx,
                'details': {
                    'sender': email['email_data'].get('sender', ''),
                    'date': email['email_data'].get('date'),
                    'entities_count': len(email.get('entities', [])),
                    'provenance_tracked': bool(email.get('provenance')),
                    'filename': email.get('filename', '')
                },
                'compliance_status': 'compliant',
                'data_integrity_hash': generate_email_hash(email)
            }
            
            audit_trail.append(email_audit)
    
    return audit_trail

def generate_event_id() -> str:
    """Generate unique event ID for audit trail"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    return f"evt_{timestamp}"

def calculate_thread_timespan(emails: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """
    Calculate timespan information for a thread
    
    Args:
        emails: List of email data
        
    Returns:
        Dictionary with timespan information or None
    """
    if not emails:
        return None
    
    dates = []
    for email in emails:
        date = email['email_data'].get('date')
        if date:
            if isinstance(date, str):
                try:
                    date = datetime.fromisoformat(date.replace('Z', '+00:00'))
                except:
                    continue
            dates.append(date)
    
    if len(dates) < 2:
        return {
            'start_date': dates[0].isoformat() if dates else None,
            'end_date': dates[0].isoformat() if dates else None,
            'duration_days': 0,
            'total_emails': len(emails)
        }
    
    dates.sort()
    duration = dates[-1] - dates[0]
    
    return {
        'start_date': dates[0].isoformat(),
        'end_date': dates[-1].isoformat(),
        'duration_days': duration.days,
        'duration_hours': duration.total_seconds() / 3600,
        'total_emails': len(emails)
    }

def generate_thread_hash(thread_data: Dict[str, Any]) -> str:
    """Generate integrity hash for thread data"""
    # Create a consistent string representation for hashing
    hash_data = {
        'thread_id': thread_data.get('thread_id', ''),
        'email_count': len(thread_data.get('emails', [])),
        'participants': sorted(thread_data.get('participants', [])),
        'subject': thread_data.get('subject', '')
    }
    
    hash_string = json.dumps(hash_data, sort_keys=True)
    return hashlib.sha256(hash_string.encode()).hexdigest()[:16]

def generate_email_hash(email_data: Dict[str, Any]) -> str:
    """Generate integrity hash for email data"""
    hash_data = {
        'sender': email_data['email_data'].get('sender', ''),
        'subject': email_data['email_data'].get('subject', ''),
        'date': email_data['email_data'].get('date').isoformat() if email_data['email_data'].get('date') else '',
        'entity_count': len(email_data.get('entities', []))
    }
    
    hash_string = json.dumps(hash_data, sort_keys=True)
    return hashlib.sha256(hash_string.encode()).hexdigest()[:16]

def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename for safe storage
    
    Args:
        filename: Original filename
        
    Returns:
        Sanitized filename
    """
    # Remove or replace invalid characters
    sanitized = re.sub(r'[<>:"/\\|?*]', '_', filename)
    sanitized = re.sub(r'\s+', '_', sanitized)
    sanitized = sanitized.strip('._')
    
    # Ensure reasonable length
    if len(sanitized) > 100:
        name, ext = sanitized.rsplit('.', 1) if '.' in sanitized else (sanitized, '')
        sanitized = name[:95] + ('.' + ext if ext else '')
    
    return sanitized or 'unnamed_file'

def validate_email_data(email_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate email data structure and return validation results
    
    Args:
        email_data: Email data dictionary
        
    Returns:
        Validation results with errors and warnings
    """
    validation_result = {
        'is_valid': True,
        'errors': [],
        'warnings': [],
        'completeness_score': 0.0
    }
    
    required_fields = ['sender', 'subject', 'date', 'body']
    optional_fields = ['recipients', 'message_id', 'attachments']
    
    # Check required fields
    missing_required = []
    for field in required_fields:
        if not email_data.get(field):
            missing_required.append(field)
    
    if missing_required:
        validation_result['is_valid'] = False
        validation_result['errors'].append(f"Missing required fields: {', '.join(missing_required)}")
    
    # Check optional fields for completeness
    present_optional = sum(1 for field in optional_fields if email_data.get(field))
    total_fields = len(required_fields) + len(optional_fields)
    present_fields = len(required_fields) - len(missing_required) + present_optional
    validation_result['completeness_score'] = (present_fields / total_fields) * 100
    
    # Validate email format
    sender = email_data.get('sender', '')
    if sender and not re.match(r'^[^@]+@[^@]+\.[^@]+$', sender):
        validation_result['warnings'].append(f"Sender email format may be invalid: {sender}")
    
    # Validate date
    date_value = email_data.get('date')
    if date_value:
        if isinstance(date_value, str):
            try:
                datetime.fromisoformat(date_value.replace('Z', '+00:00'))
            except:
                validation_result['warnings'].append("Date format may be invalid")
        elif not isinstance(date_value, datetime):
            validation_result['warnings'].append("Date should be datetime object or ISO string")
    
    # Check body length
    body = email_data.get('body', '')
    if len(body) < 10:
        validation_result['warnings'].append("Email body is very short")
    elif len(body) > 100000:
        validation_result['warnings'].append("Email body is very long")
    
    return validation_result

def extract_financial_indicators(text: str) -> Dict[str, List[str]]:
    """
    Extract basic financial indicators from text
    
    Args:
        text: Text to analyze
        
    Returns:
        Dictionary with found indicators by category
    """
    if not text:
        return {}
    
    text_lower = text.lower()
    
    indicators = {
        'urgency_keywords': [],
        'risk_keywords': [],
        'amount_references': [],
        'date_references': [],
        'regulatory_keywords': []
    }
    
    # Urgency indicators
    urgency_patterns = ['urgent', 'asap', 'immediate', 'critical', 'emergency', 'priority']
    for pattern in urgency_patterns:
        if pattern in text_lower:
            indicators['urgency_keywords'].append(pattern)
    
    # Risk indicators
    risk_patterns = ['risk', 'exposure', 'breach', 'violation', 'exception', 'error', 'fail']
    for pattern in risk_patterns:
        if pattern in text_lower:
            indicators['risk_keywords'].append(pattern)
    
    # Amount references
    amount_patterns = [
        r'\$[\d,]+\.?\d*',
        r'[\d,]+\.?\d*\s*(USD|EUR|GBP|JPY|million|billion)',
        r'(amount|notional|value)[\s:]+[\d,]+\.?\d*'
    ]
    for pattern in amount_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        indicators['amount_references'].extend(matches)
    
    # Date references
    date_patterns = [
        r'\d{1,2}[-/]\d{1,2}[-/]\d{2,4}',
        r'(trade date|settlement date|maturity date)',
        r'(today|tomorrow|yesterday|next week|last week)'
    ]
    for pattern in date_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        indicators['date_references'].extend(matches)
    
    # Regulatory keywords
    regulatory_patterns = ['compliance', 'regulatory', 'audit', 'investigation', 'reporting']
    for pattern in regulatory_patterns:
        if pattern in text_lower:
            indicators['regulatory_keywords'].append(pattern)
    
    # Remove duplicates and empty entries
    for key in indicators:
        indicators[key] = list(set(filter(None, indicators[key])))
    
    return indicators

def calculate_content_similarity(text1: str, text2: str) -> float:
    """
    Calculate similarity between two text contents
    
    Args:
        text1: First text
        text2: Second text
        
    Returns:
        Similarity score between 0 and 1
    """
    if not text1 or not text2:
        return 0.0
    
    # Convert to lowercase and split into words
    words1 = set(re.findall(r'\w+', text1.lower()))
    words2 = set(re.findall(r'\w+', text2.lower()))
    
    if not words1 or not words2:
        return 0.0
    
    # Calculate Jaccard similarity
    intersection = words1 & words2
    union = words1 | words2
    
    return len(intersection) / len(union) if union else 0.0

def format_entity_display(entity: Dict[str, Any]) -> str:
    """
    Format entity for display in UI
    
    Args:
        entity: Entity dictionary
        
    Returns:
        Formatted string for display
    """
    entity_type = entity.get('entity_type', 'unknown').replace('_', ' ').title()
    value = entity.get('value', 'N/A')
    confidence = entity.get('confidence', 0.0)
    
    confidence_indicator = "🟢" if confidence > 0.8 else "🟡" if confidence > 0.6 else "🔴"
    
    return f"{confidence_indicator} {entity_type}: {value} ({confidence:.2f})"

def create_export_filename(prefix: str, extension: str) -> str:
    """
    Create filename for exports with timestamp
    
    Args:
        prefix: Filename prefix
        extension: File extension (without dot)
        
    Returns:
        Generated filename
    """
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    return f"{prefix}_{timestamp}.{extension}"

def validate_thread_integrity(thread_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate thread data integrity
    
    Args:
        thread_data: Thread data to validate
        
    Returns:
        Validation results
    """
    validation = {
        'is_valid': True,
        'issues': [],
        'warnings': [],
        'integrity_score': 100.0
    }
    
    emails = thread_data.get('emails', [])
    
    # Check if thread has emails
    if not emails:
        validation['is_valid'] = False
        validation['issues'].append("Thread contains no emails")
        validation['integrity_score'] = 0.0
        return validation
    
    # Check chronological order
    dates = []
    for email in emails:
        date = email['email_data'].get('date')
        if date:
            dates.append(date)
    
    if len(dates) > 1:
        sorted_dates = sorted(dates)
        if dates != sorted_dates:
            validation['warnings'].append("Emails may not be in chronological order")
            validation['integrity_score'] -= 10
    
    # Check participant consistency
    participants = set()
    for email in emails:
        sender = email['email_data'].get('sender')
        if sender:
            participants.add(sender)
        recipients = email['email_data'].get('recipients', [])
        participants.update(recipients)
    
    declared_participants = set(thread_data.get('participants', []))
    if participants != declared_participants:
        validation['warnings'].append("Participant list may be incomplete")
        validation['integrity_score'] -= 5
    
    # Check for missing message IDs (affects thread reconstruction reliability)
    missing_msg_ids = sum(1 for email in emails if not email['email_data'].get('message_id'))
    if missing_msg_ids > 0:
        validation['warnings'].append(f"{missing_msg_ids} emails missing message IDs")
        validation['integrity_score'] -= (missing_msg_ids / len(emails)) * 20
    
    validation['integrity_score'] = max(0.0, validation['integrity_score'])
    
    return validation

def safe_json_serialize(obj: Any) -> str:
    """
    Safely serialize object to JSON, handling datetime and other non-serializable types
    
    Args:
        obj: Object to serialize
        
    Returns:
        JSON string
    """
    def json_serializer(o):
        if isinstance(o, datetime):
            return o.isoformat()
        elif hasattr(o, '__dict__'):
            return o.__dict__
        else:
            return str(o)
    
    try:
        return json.dumps(obj, default=json_serializer, indent=2)
    except Exception as e:
        return json.dumps({'error': f'Serialization failed: {str(e)}'}, indent=2)

def estimate_processing_time(email_count: int) -> Dict[str, float]:
    """
    Estimate processing time based on email count
    
    Args:
        email_count: Number of emails to process
        
    Returns:
        Time estimates in different units
    """
    # Base estimates (in seconds per email)
    base_time_per_email = 2.5  # Conservative estimate including parsing, extraction, summarization
    
    total_seconds = email_count * base_time_per_email
    
    return {
        'total_seconds': total_seconds,
        'total_minutes': total_seconds / 60,
        'total_hours': total_seconds / 3600,
        'estimated_completion': (datetime.now().timestamp() + total_seconds),
        'complexity_factor': min(1.5, 1.0 + (email_count / 1000))  # Increases with volume
    }

def create_processing_summary(threads: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """
    Create summary of processing results
    
    Args:
        threads: Processed thread data
        
    Returns:
        Processing summary statistics
    """
    total_emails = sum(len(thread.get('emails', [])) for thread in threads.values())
    total_entities = sum(
        len(email.get('entities', [])) 
        for thread in threads.values() 
        for email in thread.get('emails', [])
    )
    
    # Calculate participant statistics
    all_participants = set()
    for thread in threads.values():
        all_participants.update(thread.get('participants', []))
    
    # Calculate time span
    all_dates = []
    for thread in threads.values():
        for email in thread.get('emails', []):
            date = email['email_data'].get('date')
            if date:
                all_dates.append(date)
    
    time_span_days = None
    if len(all_dates) >= 2:
        all_dates.sort()
        time_span_days = (all_dates[-1] - all_dates[0]).days
    
    # Entity type distribution
    entity_types = {}
    for thread in threads.values():
        for email in thread.get('emails', []):
            for entity in email.get('entities', []):
                entity_type = entity.get('entity_type', 'unknown')
                entity_types[entity_type] = entity_types.get(entity_type, 0) + 1
    
    return {
        'processing_timestamp': datetime.now().isoformat(),
        'total_threads': len(threads),
        'total_emails': total_emails,
        'total_entities': total_entities,
        'unique_participants': len(all_participants),
        'time_span_days': time_span_days,
        'entity_type_distribution': entity_types,
        'average_emails_per_thread': total_emails / len(threads) if threads else 0,
        'average_entities_per_email': total_entities / total_emails if total_emails else 0,
        'threads_with_summaries': sum(1 for thread in threads.values() if thread.get('summary')),
        'data_quality_score': calculate_data_quality_score(threads)
    }

def calculate_data_quality_score(threads: Dict[str, Dict[str, Any]]) -> float:
    """
    Calculate overall data quality score for processed threads
    
    Args:
        threads: Processed thread data
        
    Returns:
        Quality score between 0 and 100
    """
    if not threads:
        return 0.0
    
    total_score = 0.0
    total_emails = 0
    
    for thread in threads.values():
        emails = thread.get('emails', [])
        thread_score = 0.0
        
        for email in emails:
            email_score = 100.0  # Start with perfect score
            
            # Deduct for missing fields
            email_data = email['email_data']
            if not email_data.get('sender'):
                email_score -= 20
            if not email_data.get('subject'):
                email_score -= 10
            if not email_data.get('date'):
                email_score -= 15
            if not email_data.get('message_id'):
                email_score -= 10
            if not email_data.get('body'):
                email_score -= 25
            
            # Bonus for extracted entities
            entities = email.get('entities', [])
            if entities:
                email_score += min(20, len(entities) * 2)  # Max 20 bonus points
            
            # Bonus for provenance tracking
            if email.get('provenance'):
                email_score += 10
            
            thread_score += max(0, min(100, email_score))
            total_emails += 1
        
        total_score += thread_score
    
    return (total_score / total_emails) if total_emails > 0 else 0.0
