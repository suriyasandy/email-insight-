# Financial Trade Email Surveillance System

## Overview

This is a governance-compliant email surveillance system designed specifically for financial trade monitoring. The system processes .msg email files to extract, analyze, and summarize trade-related communications while maintaining complete content provenance for regulatory compliance. It reconstructs email threads, extracts financial entities (trade IDs, amounts, currencies, counterparties), and provides extractive summarization with full source attribution.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit web application with multi-page navigation
- **UI Pattern**: Session-state management for persistent data across user interactions
- **Layout**: Wide layout with sidebar navigation for different functional areas
- **Caching**: Resource caching for module initialization to improve performance

### Core Processing Pipeline
- **Email Parser**: Handles .msg file format using extract_msg library for email content extraction
- **Thread Reconstructor**: Rebuilds conversation threads using message headers (In-Reply-To, References) and subject analysis
- **Entity Extractor**: Rule-based system using regex patterns and gazetteers for financial entity identification
- **Summarizer**: Extractive summarization engine with priority-based sentence ranking for financial content
- **Provenance Tracker**: Complete audit trail system for regulatory compliance and source attribution

### Data Processing Patterns
- **Rule-Based Entity Extraction**: Uses configurable JSON patterns and gazetteers for financial terms (currencies, institutions, products, risk measures)
- **Thread Reconstruction**: Message ID-based threading with fallback to subject-based grouping
- **Extractive Summarization**: Keyword-weighted sentence scoring with source attribution
- **Content Hashing**: SHA-256 hashing for content integrity and duplicate detection

### Configuration Management
- **Pattern Configuration**: JSON-based regex patterns for trade entities (trade_patterns.json)
- **Gazetteer System**: Comprehensive lists of financial terms, institutions, and regulatory concepts (gazetteers.json)
- **Feedback Storage**: JSON-based feedback collection for continuous improvement (feedback_store.json)

### Data Models
- **Email Data Structure**: Standardized email representation with headers, body, attachments, and metadata
- **Thread Structure**: Hierarchical thread representation with chronological ordering and participant tracking
- **Entity Structure**: Typed entities with confidence scores, source positions, and provenance links
- **Provenance Records**: Complete audit trail with content hashes, processing timestamps, and source attribution

### Security and Compliance Features
- **Content Provenance**: Full lineage tracking from source email to extracted entities and summaries
- **Audit Trail**: Comprehensive logging of all processing steps and user interactions
- **Source Attribution**: Every piece of information is traceable back to its original source
- **Hash-Based Integrity**: Content verification through cryptographic hashing

## External Dependencies

### Core Libraries
- **streamlit**: Web application framework for the user interface
- **extract_msg**: Microsoft Outlook .msg file parsing library
- **pandas**: Data manipulation and analysis for structured data handling
- **beautifulsoup4**: HTML parsing for email body content processing

### Utility Libraries
- **datetime**: Timestamp handling and date operations
- **pathlib**: File system path operations
- **json**: Configuration file parsing and data serialization
- **re**: Regular expression processing for entity extraction
- **hashlib**: Cryptographic hashing for content integrity
- **io**: In-memory file operations for email processing
- **zipfile**: Archive handling for bulk email processing
- **collections**: Advanced data structures (defaultdict, Counter, deque)

### File System Dependencies
- **Configuration Files**: JSON-based pattern and gazetteer configurations
- **Data Storage**: JSON-based feedback and audit trail storage
- **Upload Processing**: Temporary file handling for email uploads

Note: The system is designed to be self-contained with minimal external service dependencies, focusing on local processing for security and compliance requirements.