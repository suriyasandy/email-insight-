import streamlit as st
import pandas as pd
import json
from datetime import datetime
import io
import zipfile
from pathlib import Path

from modules.email_parser import EmailParser
from modules.thread_reconstructor import ThreadReconstructor
from modules.entity_extractor import EntityExtractor
from modules.summarizer import EmailSummarizer
from modules.provenance_tracker import ProvenanceTracker
from utils.helpers import format_timestamp, create_audit_trail

# Page configuration
st.set_page_config(
    page_title="Financial Trade Email Surveillance System",
    page_icon="📧",
    layout="wide"
)

# Initialize session state
if 'processed_emails' not in st.session_state:
    st.session_state.processed_emails = []
if 'feedback_data' not in st.session_state:
    st.session_state.feedback_data = []
if 'selected_thread' not in st.session_state:
    st.session_state.selected_thread = None

# Initialize modules
@st.cache_resource
def init_modules():
    email_parser = EmailParser()
    thread_reconstructor = ThreadReconstructor()
    entity_extractor = EntityExtractor()
    summarizer = EmailSummarizer()
    provenance_tracker = ProvenanceTracker()
    return email_parser, thread_reconstructor, entity_extractor, summarizer, provenance_tracker

def main():
    st.title("🏦 Financial Trade Email Surveillance System")
    st.markdown("**Governance-compliant email chain summarization with full content provenance**")
    
    # Initialize modules
    email_parser, thread_reconstructor, entity_extractor, summarizer, provenance_tracker = init_modules()
    
    # Sidebar navigation
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Select Page", [
        "📤 Email Processing",
        "🧵 Thread Analysis", 
        "🏷️ Entity Labeling",
        "📊 Results Export",
        "🔄 Feedback Management"
    ])
    
    if page == "📤 Email Processing":
        email_processing_page(email_parser, thread_reconstructor, entity_extractor, summarizer, provenance_tracker)
    elif page == "🧵 Thread Analysis":
        thread_analysis_page()
    elif page == "🏷️ Entity Labeling":
        entity_labeling_page(entity_extractor)
    elif page == "📊 Results Export":
        results_export_page()
    elif page == "🔄 Feedback Management":
        feedback_management_page()

def email_processing_page(email_parser, thread_reconstructor, entity_extractor, summarizer, provenance_tracker):
    st.header("📤 Email Processing")
    
    # Add sample data option
    col1, col2 = st.columns([3, 1])
    
    with col1:
        # File upload
        uploaded_files = st.file_uploader(
            "Upload .msg email files",
            type=['msg'],
            accept_multiple_files=True,
            help="Upload one or more .msg files for processing"
        )
    
    with col2:
        st.write("**Or try sample data:**")
        if st.button("📧 Load Sample Emails", type="secondary"):
            try:
                import json
                from pathlib import Path
                
                sample_file = Path('sample_processed_data.json')
                if sample_file.exists():
                    with open(sample_file, 'r') as f:
                        sample_data = json.load(f)
                    
                    # Convert string dates back to datetime objects
                    def parse_dates(obj):
                        if isinstance(obj, dict):
                            for key, value in obj.items():
                                if key in ['date', 'start_date', 'last_date', 'timestamp'] and isinstance(value, str):
                                    try:
                                        from datetime import datetime
                                        obj[key] = datetime.fromisoformat(value.replace('Z', '+00:00'))
                                    except:
                                        pass
                                elif isinstance(value, (dict, list)):
                                    parse_dates(value)
                        elif isinstance(obj, list):
                            for item in obj:
                                parse_dates(item)
                        return obj
                    
                    parsed_data = parse_dates(sample_data['threads'])
                    st.session_state.processed_emails = parsed_data
                    
                    st.success("✅ Sample email data loaded successfully!")
                    st.info("📊 Sample data includes: FX Forward trade break with Deutsche Bank, resolution thread, and extracted entities")
                    st.rerun()
                else:
                    st.error("Sample data file not found. Please run the sample demo first.")
            except Exception as e:
                st.error(f"Error loading sample data: {str(e)}")
    
    if uploaded_files:
        if st.button("Process Emails", type="primary"):
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            processed_data = []
            
            for i, uploaded_file in enumerate(uploaded_files):
                status_text.text(f"Processing {uploaded_file.name}...")
                
                try:
                    # Parse email
                    email_data = email_parser.parse_msg_file(uploaded_file)
                    
                    # Extract entities with provenance
                    entities = entity_extractor.extract_entities(email_data['body'])
                    
                    # Track provenance
                    provenance_data = provenance_tracker.create_provenance_record(
                        email_data, entities, uploaded_file.name
                    )
                    
                    processed_data.append({
                        'filename': uploaded_file.name,
                        'email_data': email_data,
                        'entities': entities,
                        'provenance': provenance_data
                    })
                    
                except Exception as e:
                    st.error(f"Error processing {uploaded_file.name}: {str(e)}")
                
                progress_bar.progress((i + 1) / len(uploaded_files))
            
            if processed_data:
                # Reconstruct threads
                threads = thread_reconstructor.reconstruct_threads(processed_data)
                
                # Generate summaries for each thread
                for thread_id, thread_data in threads.items():
                    summary = summarizer.generate_thread_summary(thread_data)
                    thread_data['summary'] = summary
                
                # Store in session state
                st.session_state.processed_emails = threads
                
                status_text.text("✅ Processing complete!")
                st.success(f"Processed {len(uploaded_files)} emails into {len(threads)} conversation threads")
                
                # Display summary statistics
                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Total Emails", len(uploaded_files))
                with col2:
                    st.metric("Conversation Threads", len(threads))
                with col3:
                    total_entities = sum(len(data['entities']) for data in processed_data)
                    st.metric("Entities Extracted", total_entities)
                with col4:
                    st.metric("Processing Rate", f"{len(uploaded_files)/max(1, len(uploaded_files)*2):.1f} emails/sec")

def thread_analysis_page():
    st.header("🧵 Thread Analysis")
    
    if not st.session_state.processed_emails:
        st.warning("No processed emails found. Please process emails first.")
        return
    
    threads = st.session_state.processed_emails
    
    # Thread selection
    thread_options = [f"Thread {tid}: {data.get('subject', 'No Subject')[:50]}..." 
                     for tid, data in threads.items()]
    
    if thread_options:
        selected_thread_idx = st.selectbox("Select Thread to Analyze", range(len(thread_options)), 
                                         format_func=lambda x: thread_options[x])
        
        thread_id = list(threads.keys())[selected_thread_idx]
        thread_data = threads[thread_id]
        
        st.session_state.selected_thread = thread_id
        
        # Display thread summary
        st.subheader("Thread Summary")
        st.info(thread_data.get('summary', 'No summary available'))
        
        # Display thread hierarchy
        st.subheader("Thread Hierarchy")
        
        emails = thread_data.get('emails', [])
        
        for i, email in enumerate(emails):
            with st.expander(f"📧 Email {i+1}: {email['email_data']['sender']} - {format_timestamp(email['email_data']['date'])}"):
                
                # Email metadata
                col1, col2 = st.columns(2)
                with col1:
                    st.write("**From:**", email['email_data']['sender'])
                    st.write("**Date:**", format_timestamp(email['email_data']['date']))
                with col2:
                    st.write("**Subject:**", email['email_data']['subject'])
                    st.write("**Message ID:**", email['email_data'].get('message_id', 'N/A'))
                
                # Email body preview
                st.write("**Body Preview:**")
                body_preview = email['email_data']['body'][:500] + "..." if len(email['email_data']['body']) > 500 else email['email_data']['body']
                st.text_area("", value=body_preview, height=150, key=f"body_{thread_id}_{i}", disabled=True)
                
                # Extracted entities with source attribution
                if email['entities']:
                    st.write("**Extracted Trade Attributes:**")
                    entities_df = pd.DataFrame(email['entities'])
                    st.dataframe(entities_df, use_container_width=True)

def entity_labeling_page(entity_extractor):
    st.header("🏷️ Entity Labeling & Feedback")
    
    if not st.session_state.processed_emails:
        st.warning("No processed emails found. Please process emails first.")
        return
    
    st.subheader("Interactive Entity Correction")
    
    # Select thread for labeling
    threads = st.session_state.processed_emails
    thread_options = [f"Thread {tid}: {data.get('subject', 'No Subject')[:50]}..." 
                     for tid, data in threads.items()]
    
    if thread_options:
        selected_thread_idx = st.selectbox("Select Thread for Labeling", range(len(thread_options)), 
                                         format_func=lambda x: thread_options[x])
        
        thread_id = list(threads.keys())[selected_thread_idx]
        thread_data = threads[thread_id]
        
        emails = thread_data.get('emails', [])
        
        for email_idx, email in enumerate(emails):
            st.write(f"**Email {email_idx + 1} from {email['email_data']['sender']}**")
            
            # Display current entities
            current_entities = email.get('entities', [])
            
            if current_entities:
                entities_df = pd.DataFrame(current_entities)
                edited_df = st.data_editor(
                    entities_df,
                    num_rows="dynamic",
                    key=f"entities_{thread_id}_{email_idx}"
                )
                
                # Check for changes
                if not edited_df.equals(entities_df):
                    if st.button(f"Save Changes for Email {email_idx + 1}", key=f"save_{thread_id}_{email_idx}"):
                        # Store feedback
                        feedback_record = {
                            'thread_id': thread_id,
                            'email_index': email_idx,
                            'original_entities': current_entities,
                            'corrected_entities': edited_df.to_dict('records'),
                            'timestamp': datetime.now().isoformat(),
                            'user': 'ops_user'  # In real implementation, get from auth
                        }
                        
                        st.session_state.feedback_data.append(feedback_record)
                        
                        # Update the processed data
                        st.session_state.processed_emails[thread_id]['emails'][email_idx]['entities'] = edited_df.to_dict('records')
                        
                        st.success("Changes saved! This feedback will be used to improve extraction patterns.")
                        st.rerun()
            else:
                st.write("No entities extracted for this email.")
                
                # Allow manual entity addition
                with st.expander("Add Manual Entities"):
                    new_entity_type = st.selectbox("Entity Type", ["trade_id", "amount", "currency", "counterparty", "product", "other"])
                    new_entity_value = st.text_input("Entity Value")
                    new_entity_position = st.number_input("Position in Text", min_value=0, value=0)
                    
                    if st.button(f"Add Entity to Email {email_idx + 1}", key=f"add_{thread_id}_{email_idx}"):
                        if new_entity_value.strip():
                            new_entity = {
                                'entity_type': new_entity_type,
                                'value': new_entity_value,
                                'position': new_entity_position,
                                'confidence': 1.0,  # Manual entries get full confidence
                                'source': 'manual_label'
                            }
                            
                            if 'entities' not in st.session_state.processed_emails[thread_id]['emails'][email_idx]:
                                st.session_state.processed_emails[thread_id]['emails'][email_idx]['entities'] = []
                            
                            st.session_state.processed_emails[thread_id]['emails'][email_idx]['entities'].append(new_entity)
                            
                            st.success("Entity added successfully!")
                            st.rerun()

def results_export_page():
    st.header("📊 Results Export")
    
    if not st.session_state.processed_emails:
        st.warning("No processed emails found. Please process emails first.")
        return
    
    threads = st.session_state.processed_emails
    
    st.subheader("Export Options")
    
    export_format = st.radio("Select Export Format", ["CSV", "JSON", "Detailed Report"])
    
    if st.button("Generate Export", type="primary"):
        if export_format == "CSV":
            # Create CSV with full traceability
            export_data = []
            
            for thread_id, thread_data in threads.items():
                emails = thread_data.get('emails', [])
                
                for email_idx, email in enumerate(emails):
                    base_row = {
                        'thread_id': thread_id,
                        'email_index': email_idx,
                        'sender': email['email_data']['sender'],
                        'date': email['email_data']['date'],
                        'subject': email['email_data']['subject'],
                        'message_id': email['email_data'].get('message_id', ''),
                        'thread_summary': thread_data.get('summary', '')
                    }
                    
                    entities = email.get('entities', [])
                    if entities:
                        for entity in entities:
                            row = base_row.copy()
                            row.update(entity)
                            export_data.append(row)
                    else:
                        export_data.append(base_row)
            
            df = pd.DataFrame(export_data)
            csv_buffer = io.StringIO()
            df.to_csv(csv_buffer, index=False)
            
            st.download_button(
                label="Download CSV",
                data=csv_buffer.getvalue(),
                file_name=f"email_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
            
        elif export_format == "JSON":
            # Create JSON with complete provenance
            export_data = {
                'export_timestamp': datetime.now().isoformat(),
                'threads': threads,
                'audit_trail': create_audit_trail(threads),
                'feedback_records': st.session_state.feedback_data
            }
            
            json_str = json.dumps(export_data, indent=2, default=str)
            
            st.download_button(
                label="Download JSON",
                data=json_str,
                file_name=f"email_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )
            
        elif export_format == "Detailed Report":
            # Generate comprehensive HTML report
            html_content = generate_detailed_report(threads, st.session_state.feedback_data)
            
            st.download_button(
                label="Download Detailed Report",
                data=html_content,
                file_name=f"email_surveillance_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html",
                mime="text/html"
            )
    
    # Display summary statistics
    st.subheader("Processing Summary")
    
    total_emails = sum(len(thread_data.get('emails', [])) for thread_data in threads.values())
    total_entities = sum(
        len(email.get('entities', [])) 
        for thread_data in threads.values() 
        for email in thread_data.get('emails', [])
    )
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Threads", len(threads))
    with col2:
        st.metric("Total Emails", total_emails)
    with col3:
        st.metric("Total Entities", total_entities)

def feedback_management_page():
    st.header("🔄 Feedback Management")
    
    st.subheader("Feedback Statistics")
    
    if st.session_state.feedback_data:
        feedback_df = pd.DataFrame(st.session_state.feedback_data)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Feedback Records", len(feedback_df))
        with col2:
            st.metric("Unique Threads Modified", feedback_df['thread_id'].nunique())
        with col3:
            try:
                recent_feedback = len(feedback_df[pd.to_datetime(feedback_df['timestamp']) > pd.Timestamp.now() - pd.Timedelta(days=7)])
                st.metric("Recent Feedback (7 days)", int(recent_feedback))
            except:
                st.metric("Recent Feedback (7 days)", 0)
        
        st.subheader("Feedback Records")
        st.dataframe(feedback_df, use_container_width=True)
        
        # Export feedback for model retraining
        if st.button("Export Feedback for Model Training"):
            feedback_json = json.dumps(st.session_state.feedback_data, indent=2, default=str)
            
            st.download_button(
                label="Download Feedback Data",
                data=feedback_json,
                file_name=f"feedback_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )
    else:
        st.info("No feedback data available yet. Use the Entity Labeling page to provide corrections and improvements.")
    
    # Clear feedback option
    if st.session_state.feedback_data:
        if st.button("Clear All Feedback Data", type="secondary"):
            if st.checkbox("I confirm I want to clear all feedback data"):
                st.session_state.feedback_data = []
                st.success("Feedback data cleared.")
                st.rerun()

def generate_detailed_report(threads, feedback_data):
    """Generate a comprehensive HTML report"""
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Email Surveillance Report - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; }}
            .header {{ background-color: #f0f0f0; padding: 20px; border-radius: 5px; }}
            .thread {{ margin: 20px 0; border: 1px solid #ddd; border-radius: 5px; }}
            .thread-header {{ background-color: #e8f4f8; padding: 15px; font-weight: bold; }}
            .email {{ margin: 10px; padding: 10px; border-left: 3px solid #007acc; }}
            .entities {{ background-color: #f9f9f9; padding: 10px; margin: 10px 0; }}
            .audit-info {{ color: #666; font-size: 0.9em; }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>Financial Trade Email Surveillance Report</h1>
            <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p>Total Threads: {len(threads)}</p>
        </div>
    """
    
    for thread_id, thread_data in threads.items():
        html_content += f"""
        <div class="thread">
            <div class="thread-header">Thread {thread_id}: {thread_data.get('subject', 'No Subject')}</div>
            <div style="padding: 15px;">
                <h3>Summary:</h3>
                <p>{thread_data.get('summary', 'No summary available')}</p>
                <h3>Emails in Thread:</h3>
        """
        
        for i, email in enumerate(thread_data.get('emails', [])):
            html_content += f"""
                <div class="email">
                    <h4>Email {i+1}</h4>
                    <p><strong>From:</strong> {email['email_data']['sender']}</p>
                    <p><strong>Date:</strong> {format_timestamp(email['email_data']['date'])}</p>
                    <p><strong>Subject:</strong> {email['email_data']['subject']}</p>
                    
                    <div class="entities">
                        <h5>Extracted Entities:</h5>
            """
            
            entities = email.get('entities', [])
            if entities:
                for entity in entities:
                    html_content += f"<p>• {entity.get('entity_type', 'Unknown')}: {entity.get('value', 'N/A')} (Confidence: {entity.get('confidence', 0):.2f})</p>"
            else:
                html_content += "<p>No entities extracted</p>"
            
            html_content += """
                    </div>
                </div>
            """
        
        html_content += """
            </div>
        </div>
        """
    
    html_content += """
        <div class="audit-info">
            <h2>Audit Information</h2>
            <p>This report maintains full content provenance and source attribution for regulatory compliance.</p>
        </div>
    </body>
    </html>
    """
    
    return html_content

if __name__ == "__main__":
    main()
