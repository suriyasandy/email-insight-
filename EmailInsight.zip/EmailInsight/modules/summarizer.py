from typing import List, Dict, Any, Tuple
from collections import Counter, defaultdict
import re
from datetime import datetime

class EmailSummarizer:
    """Extractive summarization with source attribution for financial emails"""
    
    def __init__(self):
        self.financial_keywords = {
            'high_priority': [
                'trade', 'settlement', 'breach', 'exception', 'risk', 'exposure',
                'margin', 'threshold', 'violation', 'error', 'fail', 'break',
                'urgent', 'critical', 'immediate', 'regulatory', 'compliance'
            ],
            'medium_priority': [
                'amount', 'notional', 'currency', 'counterparty', 'portfolio',
                'book', 'product', 'maturity', 'value', 'price', 'rate'
            ],
            'low_priority': [
                'confirm', 'acknowledge', 'update', 'information', 'details',
                'report', 'summary', 'status', 'review'
            ]
        }
        
        self.sentence_separators = ['.', '!', '?', '\n\n']
        self.min_sentence_length = 10
        self.max_summary_sentences = 5
    
    def generate_thread_summary(self, thread_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate extractive summary for an email thread with full source attribution
        
        Args:
            thread_data: Thread data containing emails and metadata
            
        Returns:
            Dictionary containing summary with source attribution
        """
        emails = thread_data.get('emails', [])
        
        if not emails:
            return {
                'summary_text': 'No emails found in thread.',
                'key_points': [],
                'participants_summary': [],
                'timeline': [],
                'critical_entities': [],
                'source_attribution': {}
            }
        
        # Extract and score sentences from all emails
        all_sentences = []
        
        for email_idx, email in enumerate(emails):
            email_data = email['email_data']
            body_text = email_data.get('body', '')
            
            if not body_text:
                continue
            
            sentences = self._extract_sentences(body_text)
            
            for sentence in sentences:
                if len(sentence.strip()) >= self.min_sentence_length:
                    sentence_data = {
                        'text': sentence.strip(),
                        'email_index': email_idx,
                        'sender': email_data.get('sender', ''),
                        'date': email_data.get('date'),
                        'entities': self._get_sentence_entities(sentence, email.get('entities', [])),
                        'score': self._score_sentence(sentence, email.get('entities', [])),
                        'keywords': self._extract_keywords(sentence),
                        'position_in_email': sentences.index(sentence)
                    }
                    all_sentences.append(sentence_data)
        
        # Sort sentences by score
        scored_sentences = sorted(all_sentences, key=lambda x: x['score'], reverse=True)
        
        # Select top sentences for summary
        summary_sentences = scored_sentences[:self.max_summary_sentences]
        
        # Create comprehensive summary
        summary = self._create_comprehensive_summary(thread_data, summary_sentences, all_sentences)
        
        return summary
    
    def _extract_sentences(self, text: str) -> List[str]:
        """Extract sentences from text"""
        if not text:
            return []
        
        # Simple sentence splitting - can be improved with more sophisticated methods
        sentences = []
        
        # Split by sentence separators
        current_sentence = ""
        
        for char in text:
            current_sentence += char
            
            if char in self.sentence_separators:
                sentence = current_sentence.strip()
                if sentence:
                    sentences.append(sentence)
                current_sentence = ""
        
        # Add remaining text as last sentence
        if current_sentence.strip():
            sentences.append(current_sentence.strip())
        
        return sentences
    
    def _get_sentence_entities(self, sentence: str, email_entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Find entities that appear in this sentence"""
        sentence_entities = []
        
        for entity in email_entities:
            entity_value = entity.get('value', '')
            if entity_value and entity_value.lower() in sentence.lower():
                sentence_entities.append(entity)
        
        return sentence_entities
    
    def _score_sentence(self, sentence: str, email_entities: List[Dict[str, Any]]) -> float:
        """Score sentence based on financial relevance and entity density"""
        score = 0.0
        sentence_lower = sentence.lower()
        
        # Keyword-based scoring
        for priority, keywords in self.financial_keywords.items():
            for keyword in keywords:
                if keyword in sentence_lower:
                    if priority == 'high_priority':
                        score += 3.0
                    elif priority == 'medium_priority':
                        score += 2.0
                    else:
                        score += 1.0
        
        # Entity density scoring
        sentence_entities = self._get_sentence_entities(sentence, email_entities)
        entity_score = len(sentence_entities) * 1.5
        score += entity_score
        
        # Length normalization (prefer sentences that are not too short or too long)
        length = len(sentence.split())
        if 10 <= length <= 30:
            score += 1.0
        elif length < 5:
            score -= 1.0
        elif length > 50:
            score -= 0.5
        
        # Position-based scoring (first and last sentences often important)
        # This would need to be implemented when we know sentence position
        
        # Financial pattern scoring
        financial_patterns = [
            r'\$[\d,]+\.?\d*',  # Dollar amounts
            r'[\d,]+\.?\d*\s*(USD|EUR|GBP|JPY)',  # Currency amounts
            r'\d+\.\d+%',  # Percentages
            r'trade\s+\w+',  # Trade references
            r'breach|violation|exception',  # Risk terms
        ]
        
        for pattern in financial_patterns:
            matches = re.findall(pattern, sentence, re.IGNORECASE)
            score += len(matches) * 0.5
        
        return score
    
    def _extract_keywords(self, sentence: str) -> List[str]:
        """Extract important keywords from sentence"""
        keywords = []
        sentence_lower = sentence.lower()
        
        for priority_keywords in self.financial_keywords.values():
            for keyword in priority_keywords:
                if keyword in sentence_lower:
                    keywords.append(keyword)
        
        return list(set(keywords))  # Remove duplicates
    
    def _create_comprehensive_summary(self, thread_data: Dict[str, Any], 
                                    summary_sentences: List[Dict[str, Any]], 
                                    all_sentences: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create comprehensive summary with all attribution information"""
        
        # Main summary text
        summary_text_parts = []
        for sentence_data in summary_sentences:
            sender = sentence_data['sender']
            summary_text_parts.append(f"{sentence_data['text']} (Source: {sender})")
        
        summary_text = ' '.join(summary_text_parts)
        
        # Extract key points with attribution
        key_points = []
        for sentence_data in summary_sentences:
            key_point = {
                'text': sentence_data['text'],
                'sender': sentence_data['sender'],
                'email_index': sentence_data['email_index'],
                'date': sentence_data['date'],
                'keywords': sentence_data['keywords'],
                'entities': sentence_data['entities'],
                'confidence_score': sentence_data['score']
            }
            key_points.append(key_point)
        
        # Participants summary
        participants_summary = self._create_participants_summary(thread_data, all_sentences)
        
        # Timeline of key events
        timeline = self._create_timeline(thread_data, summary_sentences)
        
        # Critical entities across the thread
        critical_entities = self._extract_critical_entities(thread_data)
        
        # Source attribution mapping
        source_attribution = self._create_source_attribution(thread_data, summary_sentences)
        
        # Thread statistics
        thread_stats = self._calculate_thread_statistics(thread_data, all_sentences)
        
        return {
            'summary_text': summary_text,
            'key_points': key_points,
            'participants_summary': participants_summary,
            'timeline': timeline,
            'critical_entities': critical_entities,
            'source_attribution': source_attribution,
            'thread_statistics': thread_stats,
            'generation_timestamp': datetime.now().isoformat(),
            'summary_method': 'extractive_with_attribution'
        }
    
    def _create_participants_summary(self, thread_data: Dict[str, Any], 
                                   all_sentences: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Create summary of participant contributions"""
        participant_contributions = defaultdict(lambda: {
            'sentence_count': 0,
            'total_score': 0.0,
            'key_topics': [],
            'entities_mentioned': []
        })
        
        for sentence_data in all_sentences:
            sender = sentence_data['sender']
            participant_contributions[sender]['sentence_count'] += 1
            participant_contributions[sender]['total_score'] += sentence_data['score']
            participant_contributions[sender]['key_topics'].extend(sentence_data['keywords'])
            participant_contributions[sender]['entities_mentioned'].extend(sentence_data['entities'])
        
        # Convert to list and add averages
        participants_summary = []
        for sender, data in participant_contributions.items():
            avg_score = data['total_score'] / data['sentence_count'] if data['sentence_count'] > 0 else 0
            
            # Get unique topics and entities
            unique_topics = list(set(data['key_topics']))
            unique_entities = list({e['value']: e for e in data['entities_mentioned']}.values())
            
            participants_summary.append({
                'sender': sender,
                'sentence_count': data['sentence_count'],
                'average_relevance_score': avg_score,
                'key_topics': unique_topics[:5],  # Top 5 topics
                'entities_mentioned': unique_entities[:10],  # Top 10 entities
                'contribution_level': 'high' if avg_score > 2.0 else 'medium' if avg_score > 1.0 else 'low'
            })
        
        return sorted(participants_summary, key=lambda x: x['average_relevance_score'], reverse=True)
    
    def _create_timeline(self, thread_data: Dict[str, Any], 
                        summary_sentences: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Create timeline of key events from summary sentences"""
        timeline_events = []
        
        # Sort summary sentences by date
        sorted_sentences = sorted(summary_sentences, key=lambda x: x['date'] or datetime.min)
        
        for sentence_data in sorted_sentences:
            event = {
                'timestamp': sentence_data['date'],
                'sender': sentence_data['sender'],
                'event_description': sentence_data['text'][:100] + '...' if len(sentence_data['text']) > 100 else sentence_data['text'],
                'full_text': sentence_data['text'],
                'email_index': sentence_data['email_index'],
                'relevance_score': sentence_data['score'],
                'entities_involved': [e['value'] for e in sentence_data['entities']]
            }
            timeline_events.append(event)
        
        return timeline_events
    
    def _extract_critical_entities(self, thread_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract the most critical entities across the thread"""
        entity_frequency = defaultdict(lambda: {
            'count': 0,
            'emails_appeared': set(),
            'total_confidence': 0.0,
            'contexts': [],
            'entity_data': None
        })
        
        emails = thread_data.get('emails', [])
        
        for email_idx, email in enumerate(emails):
            entities = email.get('entities', [])
            
            for entity in entities:
                key = (entity['entity_type'], entity['value'])
                entity_frequency[key]['count'] += 1
                entity_frequency[key]['emails_appeared'].add(email_idx)
                entity_frequency[key]['total_confidence'] += entity['confidence']
                entity_frequency[key]['contexts'].append(entity.get('context', ''))
                entity_frequency[key]['entity_data'] = entity
        
        # Convert to list and calculate importance scores
        critical_entities = []
        
        for (entity_type, value), data in entity_frequency.items():
            importance_score = (
                data['count'] * 2 +  # Frequency weight
                len(data['emails_appeared']) * 3 +  # Spread across emails
                data['total_confidence'] / data['count']  # Average confidence
            )
            
            critical_entities.append({
                'entity_type': entity_type,
                'value': value,
                'frequency': data['count'],
                'emails_appeared': list(data['emails_appeared']),
                'average_confidence': data['total_confidence'] / data['count'],
                'importance_score': importance_score,
                'contexts': data['contexts'][:3],  # Top 3 contexts
                'thread_coverage': len(data['emails_appeared']) / len(emails)
            })
        
        # Sort by importance score
        return sorted(critical_entities, key=lambda x: x['importance_score'], reverse=True)[:10]
    
    def _create_source_attribution(self, thread_data: Dict[str, Any], 
                                 summary_sentences: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create detailed source attribution for summary content"""
        attribution = {
            'summary_sources': [],
            'entity_sources': defaultdict(list),
            'key_point_sources': [],
            'email_contributions': {}
        }
        
        emails = thread_data.get('emails', [])
        
        # Track which emails contributed to summary
        for sentence_data in summary_sentences:
            email_idx = sentence_data['email_index']
            email_data = emails[email_idx]['email_data']
            
            source_info = {
                'email_index': email_idx,
                'sender': sentence_data['sender'],
                'date': sentence_data['date'],
                'sentence_text': sentence_data['text'],
                'relevance_score': sentence_data['score'],
                'position_in_summary': len(attribution['summary_sources'])
            }
            
            attribution['summary_sources'].append(source_info)
            attribution['key_point_sources'].append(source_info)
            
            # Track entities by source
            for entity in sentence_data['entities']:
                entity_key = f"{entity['entity_type']}:{entity['value']}"
                attribution['entity_sources'][entity_key].append({
                    'email_index': email_idx,
                    'sender': sentence_data['sender'],
                    'context': entity.get('context', ''),
                    'confidence': entity['confidence']
                })
        
        # Calculate email contribution scores
        email_contributions = defaultdict(lambda: {
            'sentences_used': 0,
            'total_relevance': 0.0,
            'entities_contributed': 0,
            'contribution_percentage': 0.0
        })
        
        total_relevance = sum(s['score'] for s in summary_sentences)
        
        for sentence_data in summary_sentences:
            email_idx = sentence_data['email_index']
            email_contributions[email_idx]['sentences_used'] += 1
            email_contributions[email_idx]['total_relevance'] += sentence_data['score']
            email_contributions[email_idx]['entities_contributed'] += len(sentence_data['entities'])
        
        # Calculate percentages
        for email_idx, contrib in email_contributions.items():
            contrib['contribution_percentage'] = (contrib['total_relevance'] / total_relevance * 100) if total_relevance > 0 else 0
        
        attribution['email_contributions'] = dict(email_contributions)
        
        # Convert defaultdict to regular dict
        attribution['entity_sources'] = dict(attribution['entity_sources'])
        
        return attribution
    
    def _calculate_thread_statistics(self, thread_data: Dict[str, Any], 
                                   all_sentences: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate various statistics about the thread"""
        emails = thread_data.get('emails', [])
        
        if not emails:
            return {}
        
        # Basic counts
        total_emails = len(emails)
        total_sentences = len(all_sentences)
        
        # Entity statistics
        all_entities = []
        for email in emails:
            all_entities.extend(email.get('entities', []))
        
        entity_type_counts = Counter(e['entity_type'] for e in all_entities)
        
        # Participant statistics
        senders = [email['email_data'].get('sender', '') for email in emails]
        unique_participants = len(set(senders))
        
        # Time span
        dates = [email['email_data'].get('date') for email in emails if email['email_data'].get('date')]
        time_span = None
        if len(dates) >= 2:
            dates.sort()
            time_span = (dates[-1] - dates[0]).days if dates[-1] and dates[0] else None
        
        # Content statistics
        total_words = sum(len(s['text'].split()) for s in all_sentences)
        avg_sentence_score = sum(s['score'] for s in all_sentences) / len(all_sentences) if all_sentences else 0
        
        return {
            'total_emails': total_emails,
            'total_sentences': total_sentences,
            'total_entities': len(all_entities),
            'unique_participants': unique_participants,
            'time_span_days': time_span,
            'total_words': total_words,
            'average_sentence_relevance': avg_sentence_score,
            'entity_type_distribution': dict(entity_type_counts),
            'most_active_sender': Counter(senders).most_common(1)[0][0] if senders else None,
            'thread_complexity': 'high' if total_emails > 10 else 'medium' if total_emails > 3 else 'low'
        }
