from typing import Dict, List, Any, Optional
from datetime import datetime
import json
import hashlib
import re

class ProvenanceTracker:
    """Tracks complete content provenance and source attribution for regulatory compliance"""
    
    def __init__(self):
        self.provenance_records = []
        self.entity_lineage = {}
        self.processing_history = []
    
    def create_provenance_record(self, email_data: Dict[str, Any], 
                                entities: List[Dict[str, Any]], 
                                filename: str) -> Dict[str, Any]:
        """
        Create a comprehensive provenance record for processed email
        
        Args:
            email_data: Parsed email data
            entities: Extracted entities with positions
            filename: Original filename
            
        Returns:
            Complete provenance record
        """
        # Generate unique content hash
        content_hash = self._generate_content_hash(email_data, entities)
        
        # Create base provenance record
        provenance_record = {
            'record_id': content_hash,
            'timestamp': datetime.now().isoformat(),
            'source_file': {
                'filename': filename,
                'processing_timestamp': datetime.now().isoformat(),
                'file_hash': self._generate_file_hash(filename)
            },
            'email_metadata': {
                'message_id': email_data.get('message_id', ''),
                'sender': email_data.get('sender', ''),
                'recipients': email_data.get('recipients', []),
                'subject': email_data.get('subject', ''),
                'date': email_data.get('date').isoformat() if email_data.get('date') and hasattr(email_data.get('date'), 'isoformat') else str(email_data.get('date')) if email_data.get('date') else None,
                'thread_topic': email_data.get('thread_topic', '')
            },
            'content_provenance': {
                'original_body_hash': self._hash_text(email_data.get('body', '')),
                'body_length': len(email_data.get('body', '')),
                'html_body_present': bool(email_data.get('html_body')),
                'attachments_count': len(email_data.get('attachments', [])),
                'tables_extracted': len(email_data.get('tables', [])),
                'structured_content_found': bool(email_data.get('structured_content'))
            },
            'entity_provenance': self._create_entity_provenance(entities, email_data.get('body', '')),
            'processing_metadata': {
                'extraction_timestamp': datetime.now().isoformat(),
                'processing_version': '1.0',
                'entity_extraction_method': 'hybrid_rule_based',
                'total_entities_found': len(entities)
            },
            'audit_trail': [],
            'compliance_flags': {
                'pii_detected': self._check_pii(email_data, entities),
                'sensitive_content': self._check_sensitive_content(entities),
                'regulatory_keywords': self._check_regulatory_keywords(email_data.get('body', ''))
            }
        }
        
        # Add to internal tracking
        self.provenance_records.append(provenance_record)
        self._update_entity_lineage(entities, provenance_record['record_id'])
        
        return provenance_record
    
    def _update_entity_lineage(self, entities: List[Dict[str, Any]], record_id: str):
        """Update entity lineage tracking"""
        for entity in entities:
            entity_id = self._generate_entity_id(entity)
            if entity_id not in self.entity_lineage:
                self.entity_lineage[entity_id] = []
            
            # Add processing record to entity lineage
            self.entity_lineage[entity_id].append({
                'record_id': record_id,
                'timestamp': datetime.now().isoformat(),
                'action': 'extracted',
                'entity_data': entity.copy()
            })
    
    def _create_entity_provenance(self, entities: List[Dict[str, Any]], 
                                 source_text: str) -> List[Dict[str, Any]]:
        """Create detailed provenance for each extracted entity"""
        entity_provenance = []
        
        for entity in entities:
            # Extract exact context with character positions
            start_pos = entity.get('position', 0)
            end_pos = entity.get('end_position', start_pos + len(entity.get('value', '')))
            
            # Extended context for better traceability
            extended_context = self._get_extended_context(source_text, start_pos, end_pos)
            
            entity_record = {
                'entity_id': self._generate_entity_id(entity),
                'entity_type': entity.get('entity_type', ''),
                'value': entity.get('value', ''),
                'extraction_method': entity.get('extraction_method', 'pattern'),
                'confidence_score': entity.get('confidence', 0.0),
                'position_data': {
                    'char_start': start_pos,
                    'char_end': end_pos,
                    'line_number': self._get_line_number(source_text, start_pos),
                    'context_before': extended_context['before'],
                    'context_after': extended_context['after'],
                    'full_context': extended_context['full']
                },
                'extraction_details': {
                    'pattern_used': entity.get('pattern', ''),
                    'extraction_timestamp': datetime.now().isoformat(),
                    'validation_status': 'extracted',
                    'manual_review_required': entity.get('confidence', 1.0) < 0.7
                },
                'lineage': {
                    'source_email_hash': self._hash_text(source_text),
                    'entity_hash': self._hash_text(entity.get('value', '')),
                    'parent_entities': [],  # For derived entities
                    'child_entities': []    # For entities that reference this one
                }
            }
            
            entity_provenance.append(entity_record)
        
        return entity_provenance
    
    def track_entity_correction(self, original_entity: Dict[str, Any], 
                               corrected_entity: Dict[str, Any], 
                               user_id: str, 
                               correction_reason: str) -> Dict[str, Any]:
        """Track entity corrections for feedback loop"""
        correction_record = {
            'correction_id': self._generate_correction_id(),
            'timestamp': datetime.now().isoformat(),
            'user_id': user_id,
            'correction_reason': correction_reason,
            'original_entity': original_entity.copy(),
            'corrected_entity': corrected_entity.copy(),
            'changes_made': self._identify_changes(original_entity, corrected_entity),
            'impact_assessment': {
                'affects_thread_summary': True,  # Default to true for safety
                'affects_entity_extraction': True,
                'pattern_learning_candidate': True
            }
        }
        
        # Update entity lineage
        entity_id = original_entity.get('entity_id') or self._generate_entity_id(original_entity)
        if entity_id not in self.entity_lineage:
            self.entity_lineage[entity_id] = []
        
        self.entity_lineage[entity_id].append(correction_record)
        
        return correction_record
    
    def track_thread_reconstruction(self, emails: List[Dict[str, Any]], 
                                  thread_result: Dict[str, Any]) -> Dict[str, Any]:
        """Track thread reconstruction provenance"""
        reconstruction_record = {
            'reconstruction_id': self._generate_reconstruction_id(),
            'timestamp': datetime.now().isoformat(),
            'input_emails': [
                {
                    'message_id': email['email_data'].get('message_id', ''),
                    'sender': email['email_data'].get('sender', ''),
                    'date': email['email_data'].get('date').isoformat() if email['email_data'].get('date') else None
                }
                for email in emails
            ],
            'reconstruction_method': 'header_based_with_subject_fallback',
            'thread_metadata': {
                'thread_id': thread_result.get('thread_id', ''),
                'emails_count': len(emails),
                'participants': thread_result.get('participants', []),
                'time_span': self._calculate_time_span(emails)
            },
            'reconstruction_decisions': self._document_reconstruction_decisions(emails, thread_result)
        }
        
        self.processing_history.append(reconstruction_record)
        return reconstruction_record
    
    def create_audit_trail(self, action: str, details: Dict[str, Any], user_id: str = None) -> Dict[str, Any]:
        """Create audit trail entry for any action"""
        audit_entry = {
            'audit_id': self._generate_audit_id(),
            'timestamp': datetime.now().isoformat(),
            'action': action,
            'user_id': user_id or 'system',
            'details': details,
            'system_context': {
                'processing_version': '1.0',
                'environment': 'production'  # Would be configurable
            }
        }
        
        return audit_entry
    
    def generate_compliance_report(self, start_date: Optional[datetime] = None, 
                                 end_date: Optional[datetime] = None) -> Dict[str, Any]:
        """Generate comprehensive compliance report with full traceability"""
        start_date_str = start_date.isoformat() if start_date else None
        end_date_str = end_date.isoformat() if end_date else None
        
        # Filter records by date range if provided
        filtered_records = []
        for record in self.provenance_records:
            record_date = datetime.fromisoformat(record['timestamp'])
            
            if start_date and record_date < start_date:
                continue
            if end_date and record_date > end_date:
                continue
                
            filtered_records.append(record)
        
        compliance_report = {
            'report_id': self._generate_report_id(),
            'generation_timestamp': datetime.now().isoformat(),
            'reporting_period': {
                'start_date': start_date_str,
                'end_date': end_date_str
            },
            'summary_statistics': {
                'total_emails_processed': len(filtered_records),
                'total_entities_extracted': sum(len(r['entity_provenance']) for r in filtered_records),
                'corrections_made': len(self.entity_lineage),
                'pii_instances_detected': sum(1 for r in filtered_records if r['compliance_flags']['pii_detected']),
                'sensitive_content_instances': sum(1 for r in filtered_records if r['compliance_flags']['sensitive_content'])
            },
            'data_lineage': self._generate_data_lineage_summary(filtered_records),
            'compliance_status': self._assess_compliance_status(filtered_records),
            'quality_metrics': self._calculate_quality_metrics(filtered_records),
            'recommendations': self._generate_recommendations(filtered_records),
            'full_provenance_records': filtered_records  # Full detail for audit
        }
        
        return compliance_report
    
    def _generate_content_hash(self, email_data: Dict[str, Any], entities: List[Dict[str, Any]]) -> str:
        """Generate unique hash for email content and entities"""
        content_string = f"{email_data.get('body', '')}{json.dumps(entities, sort_keys=True)}"
        return hashlib.sha256(content_string.encode()).hexdigest()[:16]
    
    def _generate_file_hash(self, filename: str) -> str:
        """Generate hash for filename (in real implementation, would hash file content)"""
        return hashlib.md5(filename.encode()).hexdigest()[:12]
    
    def _hash_text(self, text: str) -> str:
        """Generate hash for text content"""
        return hashlib.sha256(text.encode()).hexdigest()[:12]
    
    def _generate_entity_id(self, entity: Dict[str, Any]) -> str:
        """Generate unique ID for entity"""
        entity_string = f"{entity.get('entity_type', '')}{entity.get('value', '')}{entity.get('position', 0)}"
        return hashlib.md5(entity_string.encode()).hexdigest()[:10]
    
    def _get_extended_context(self, text: str, start_pos: int, end_pos: int, window: int = 100) -> Dict[str, str]:
        """Get extended context around entity position"""
        context_start = max(0, start_pos - window)
        context_end = min(len(text), end_pos + window)
        
        return {
            'before': text[context_start:start_pos],
            'after': text[end_pos:context_end],
            'full': text[context_start:context_end]
        }
    
    def _get_line_number(self, text: str, position: int) -> int:
        """Get line number for character position"""
        return text[:position].count('\n') + 1
    
    def _check_pii(self, email_data: Dict[str, Any], entities: List[Dict[str, Any]]) -> bool:
        """Check for potential PII in email content"""
        pii_patterns = [
            r'\b\d{3}-\d{2}-\d{4}\b',  # SSN
            r'\b\d{4}\s?\d{4}\s?\d{4}\s?\d{4}\b',  # Credit card
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'  # Email (beyond sender/recipients)
        ]
        
        text = email_data.get('body', '')
        for pattern in pii_patterns:
            if re.search(pattern, text):
                return True
        
        return False
    
    def _check_sensitive_content(self, entities: List[Dict[str, Any]]) -> bool:
        """Check for sensitive financial content"""
        sensitive_types = ['amount', 'trade_id', 'counterparty']
        
        for entity in entities:
            if entity.get('entity_type') in sensitive_types and entity.get('confidence', 0) > 0.8:
                return True
        
        return False
    
    def _check_regulatory_keywords(self, text: str) -> List[str]:
        """Check for regulatory keywords"""
        regulatory_keywords = [
            'compliance', 'regulatory', 'breach', 'violation', 'audit',
            'investigation', 'suspicious', 'aml', 'kyc', 'sanctions'
        ]
        
        found_keywords = []
        text_lower = text.lower()
        
        for keyword in regulatory_keywords:
            if keyword in text_lower:
                found_keywords.append(keyword)
        
        return found_keywords
    
    def _identify_changes(self, original: Dict[str, Any], corrected: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Identify specific changes between original and corrected entity"""
        changes = []
        
        for key in set(original.keys()) | set(corrected.keys()):
            original_value = original.get(key)
            corrected_value = corrected.get(key)
            
            if original_value != corrected_value:
                changes.append({
                    'field': key,
                    'original_value': original_value,
                    'corrected_value': corrected_value,
                    'change_type': 'modified' if key in original else 'added' if key in corrected else 'removed'
                })
        
        return changes
    
    def _calculate_time_span(self, emails: List[Dict[str, Any]]) -> Optional[int]:
        """Calculate time span of email thread in days"""
        dates = []
        for email in emails:
            date = email['email_data'].get('date')
            if date:
                dates.append(date)
        
        if len(dates) >= 2:
            dates.sort()
            return (dates[-1] - dates[0]).days
        
        return None
    
    def _document_reconstruction_decisions(self, emails: List[Dict[str, Any]], 
                                         thread_result: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Document decisions made during thread reconstruction"""
        decisions = []
        
        # Document grouping decisions
        decisions.append({
            'decision_type': 'email_grouping',
            'reasoning': 'Grouped emails based on message-id references and subject similarity',
            'confidence': 0.9,  # Would be calculated based on actual method used
            'fallback_methods_used': ['subject_matching'] if len(emails) > 1 else []
        })
        
        # Document chronological ordering
        decisions.append({
            'decision_type': 'chronological_ordering',
            'reasoning': 'Ordered emails by timestamp with fallback to received order',
            'confidence': 0.95
        })
        
        return decisions
    
    def _generate_data_lineage_summary(self, records: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary of data lineage"""
        total_entities = sum(len(r['entity_provenance']) for r in records)
        
        entity_types = {}
        extraction_methods = {}
        
        for record in records:
            for entity in record['entity_provenance']:
                entity_type = entity['entity_type']
                method = entity['extraction_method']
                
                entity_types[entity_type] = entity_types.get(entity_type, 0) + 1
                extraction_methods[method] = extraction_methods.get(method, 0) + 1
        
        return {
            'total_entities_tracked': total_entities,
            'entity_type_distribution': entity_types,
            'extraction_method_distribution': extraction_methods,
            'corrections_applied': len(self.entity_lineage)
        }
    
    def _assess_compliance_status(self, records: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Assess overall compliance status"""
        total_records = len(records)
        
        if total_records == 0:
            return {'status': 'no_data', 'score': 0}
        
        # Calculate compliance score based on various factors
        pii_violations = sum(1 for r in records if r['compliance_flags']['pii_detected'])
        incomplete_provenance = sum(1 for r in records if not r.get('entity_provenance'))
        
        compliance_score = max(0, 100 - (pii_violations * 10) - (incomplete_provenance * 5))
        
        status = 'compliant' if compliance_score >= 90 else 'warning' if compliance_score >= 70 else 'non_compliant'
        
        return {
            'status': status,
            'score': compliance_score,
            'issues_found': pii_violations + incomplete_provenance,
            'recommendations': ['Review PII handling procedures'] if pii_violations > 0 else []
        }
    
    def _calculate_quality_metrics(self, records: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate quality metrics for processed data"""
        if not records:
            return {}
        
        total_entities = sum(len(r['entity_provenance']) for r in records)
        high_confidence_entities = sum(
            1 for r in records 
            for e in r['entity_provenance'] 
            if e['confidence_score'] > 0.8
        )
        
        avg_confidence = sum(
            e['confidence_score'] 
            for r in records 
            for e in r['entity_provenance']
        ) / max(1, total_entities)
        
        return {
            'total_entities': total_entities,
            'high_confidence_percentage': (high_confidence_entities / max(1, total_entities)) * 100,
            'average_confidence': avg_confidence,
            'complete_provenance_percentage': (len([r for r in records if r.get('entity_provenance')]) / len(records)) * 100
        }
    
    def _generate_recommendations(self, records: List[Dict[str, Any]]) -> List[str]:
        """Generate recommendations based on processing results"""
        recommendations = []
        
        if not records:
            return ['No data processed yet - begin with email processing']
        
        quality_metrics = self._calculate_quality_metrics(records)
        
        if quality_metrics.get('average_confidence', 0) < 0.7:
            recommendations.append('Consider reviewing and updating entity extraction patterns for better accuracy')
        
        if quality_metrics.get('high_confidence_percentage', 0) < 80:
            recommendations.append('Implement additional validation rules to improve entity extraction confidence')
        
        pii_count = sum(1 for r in records if r['compliance_flags']['pii_detected'])
        if pii_count > 0:
            recommendations.append('Review PII detection and handling procedures')
        
        if len(self.entity_lineage) == 0:
            recommendations.append('Consider implementing feedback collection to improve extraction accuracy')
        
        return recommendations
    
    def _generate_correction_id(self) -> str:
        """Generate unique correction ID"""
        return f"corr_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{hashlib.md5(str(datetime.now()).encode()).hexdigest()[:8]}"
    
    def _generate_reconstruction_id(self) -> str:
        """Generate unique reconstruction ID"""
        return f"recon_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{hashlib.md5(str(datetime.now()).encode()).hexdigest()[:8]}"
    
    def _generate_audit_id(self) -> str:
        """Generate unique audit ID"""
        return f"audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{hashlib.md5(str(datetime.now()).encode()).hexdigest()[:8]}"
    
    def _generate_report_id(self) -> str:
        """Generate unique report ID"""
        return f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{hashlib.md5(str(datetime.now()).encode()).hexdigest()[:8]}"
