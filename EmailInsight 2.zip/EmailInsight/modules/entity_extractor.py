import re
import json
from typing import List, Dict, Any, Tuple
from pathlib import Path
from collections import defaultdict

class EntityExtractor:
    """Rule-based entity extraction for financial trade attributes"""
    
    def __init__(self):
        self.patterns = self._load_patterns()
        self.gazetteers = self._load_gazetteers()
        self.confidence_threshold = 0.5
    
    def _load_patterns(self) -> Dict[str, List[Dict[str, Any]]]:
        """Load extraction patterns from configuration"""
        try:
            with open('config/trade_patterns.json', 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return self._get_default_patterns()
    
    def _load_gazetteers(self) -> Dict[str, List[str]]:
        """Load gazetteers from configuration"""
        try:
            with open('config/gazetteers.json', 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return self._get_default_gazetteers()
    
    def _get_default_patterns(self) -> Dict[str, List[Dict[str, Any]]]:
        """Default extraction patterns for financial entities"""
        return {
            "trade_id": [
                {
                    "pattern": r"\b(trade[\s-]?id|ref|reference|deal[\s-]?id|ticket)[\s:=]+([A-Z0-9-]{6,20})\b",
                    "group": 2,
                    "confidence": 0.9,
                    "flags": "IGNORECASE"
                },
                {
                    "pattern": r"\b([A-Z]{2,4}\d{6,12})\b",
                    "group": 1,
                    "confidence": 0.7,
                    "flags": "NONE"
                }
            ],
            "amount": [
                {
                    "pattern": r"\b(amount|notional|principal|value)[\s:=]+([\d,]+\.?\d*)\b",
                    "group": 2,
                    "confidence": 0.8,
                    "flags": "IGNORECASE"
                },
                {
                    "pattern": r"\b(USD|EUR|GBP|JPY|CHF)\s*([\d,]+\.?\d*)\b",
                    "group": 2,
                    "confidence": 0.9,
                    "flags": "IGNORECASE"
                },
                {
                    "pattern": r"\b([\d,]+\.?\d*)\s*(USD|EUR|GBP|JPY|CHF|million|billion|MM|BN)\b",
                    "group": 1,
                    "confidence": 0.8,
                    "flags": "IGNORECASE"
                }
            ],
            "currency": [
                {
                    "pattern": r"\b(currency|ccy)[\s:=]+([A-Z]{3})\b",
                    "group": 2,
                    "confidence": 0.9,
                    "flags": "IGNORECASE"
                },
                {
                    "pattern": r"\b(USD|EUR|GBP|JPY|CHF|AUD|CAD|SEK|NOK|DKK)\b",
                    "group": 1,
                    "confidence": 0.8,
                    "flags": "NONE"
                }
            ],
            "counterparty": [
                {
                    "pattern": r"\b(counterparty|cp|client|customer)[\s:=]+([A-Z][A-Za-z\s&]+(?:Ltd|LLC|Inc|Corp|AG|SA|plc|Limited))\b",
                    "group": 2,
                    "confidence": 0.8,
                    "flags": "IGNORECASE"
                },
                {
                    "pattern": r"\b([A-Z][A-Za-z\s&]+(?:Bank|Capital|Securities|Investment|Trading|Financial|Fund))\b",
                    "group": 1,
                    "confidence": 0.7,
                    "flags": "NONE"
                }
            ],
            "product": [
                {
                    "pattern": r"\b(product|instrument|asset)[\s:=]+([\w\s]+)\b",
                    "group": 2,
                    "confidence": 0.7,
                    "flags": "IGNORECASE"
                },
                {
                    "pattern": r"\b(swap|option|forward|future|bond|equity|fx|credit|derivative)\b",
                    "group": 1,
                    "confidence": 0.8,
                    "flags": "IGNORECASE"
                }
            ],
            "date": [
                {
                    "pattern": r"\b(trade[\s-]?date|value[\s-]?date|settlement[\s-]?date|maturity)[\s:=]+(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})\b",
                    "group": 2,
                    "confidence": 0.9,
                    "flags": "IGNORECASE"
                },
                {
                    "pattern": r"\b(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})\b",
                    "group": 1,
                    "confidence": 0.6,
                    "flags": "NONE"
                }
            ],
            "portfolio": [
                {
                    "pattern": r"\b(portfolio|book|desk)[\s:=]+([A-Z0-9_-]+)\b",
                    "group": 2,
                    "confidence": 0.8,
                    "flags": "IGNORECASE"
                }
            ],
            "trader": [
                {
                    "pattern": r"\b(trader|sales|originator)[\s:=]+([A-Z][a-z]+\s[A-Z][a-z]+)\b",
                    "group": 2,
                    "confidence": 0.7,
                    "flags": "IGNORECASE"
                }
            ],
            "risk_metric": [
                {
                    "pattern": r"\b(pv01|dv01|gamma|vega|theta|delta)[\s:=]+([-+]?[\d,]+\.?\d*)\b",
                    "group": 0,
                    "confidence": 0.9,
                    "flags": "IGNORECASE"
                },
                {
                    "pattern": r"\b(var|stressed[\s-]?var|credit[\s-]?exposure)[\s:=]+([\d,]+\.?\d*)\b",
                    "group": 0,
                    "confidence": 0.8,
                    "flags": "IGNORECASE"
                }
            ],
            "exception_type": [
                {
                    "pattern": r"\b(exception|error|breach|violation|alert)[\s:=]+([\w\s]+)\b",
                    "group": 2,
                    "confidence": 0.7,
                    "flags": "IGNORECASE"
                },
                {
                    "pattern": r"\b(threshold[\s-]?breach|limit[\s-]?exceeded|missing[\s-]?data|trade[\s-]?break)\b",
                    "group": 1,
                    "confidence": 0.9,
                    "flags": "IGNORECASE"
                }
            ]
        }
    
    def _get_default_gazetteers(self) -> Dict[str, List[str]]:
        """Default gazetteers for entity recognition"""
        return {
            "currencies": [
                "USD", "EUR", "GBP", "JPY", "CHF", "AUD", "CAD", "SEK", "NOK", "DKK",
                "HKD", "SGD", "NZD", "ZAR", "BRL", "MXN", "CNY", "INR", "KRW", "THB"
            ],
            "financial_institutions": [
                "Goldman Sachs", "Morgan Stanley", "JP Morgan", "Citibank", "Bank of America",
                "Deutsche Bank", "UBS", "Credit Suisse", "Barclays", "HSBC", "BNP Paribas",
                "Societe Generale", "ING", "Santander", "UniCredit", "Commerzbank"
            ],
            "products": [
                "Interest Rate Swap", "Credit Default Swap", "FX Forward", "FX Option",
                "Equity Option", "Bond Future", "Commodity Future", "Swaption",
                "Cap", "Floor", "Collar", "Digital Option", "Barrier Option"
            ],
            "risk_measures": [
                "PV01", "DV01", "CS01", "IR01", "Delta", "Gamma", "Vega", "Theta", "Rho",
                "VaR", "Expected Shortfall", "Credit Exposure", "Potential Future Exposure"
            ],
            "exception_types": [
                "Trade Break", "Settlement Fail", "Margin Call", "Threshold Breach",
                "Limit Exceeded", "Missing Data", "Price Deviation", "Credit Breach",
                "Operational Risk", "Market Risk", "Counterparty Risk"
            ]
        }
    
    def extract_entities(self, text: str, source_metadata: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Extract entities from text with source attribution
        
        Args:
            text: Text to extract entities from
            source_metadata: Metadata about the source (email, sender, etc.)
            
        Returns:
            List of extracted entities with positions and confidence scores
        """
        if not text:
            return []
        
        entities = []
        
        # Pattern-based extraction
        for entity_type, patterns in self.patterns.items():
            entities.extend(self._extract_by_pattern(text, entity_type, patterns))
        
        # Gazetteer-based extraction
        for entity_type, gazetteer in self.gazetteers.items():
            entities.extend(self._extract_by_gazetteer(text, entity_type, gazetteer))
        
        # Filter by confidence threshold
        filtered_entities = [e for e in entities if e['confidence'] >= self.confidence_threshold]
        
        # Add source metadata
        for entity in filtered_entities:
            entity['source_metadata'] = source_metadata or {}
            entity['extraction_method'] = entity.get('extraction_method', 'pattern')
        
        # Remove duplicates and merge overlapping entities
        final_entities = self._post_process_entities(filtered_entities)
        
        return final_entities
    
    def _extract_by_pattern(self, text: str, entity_type: str, patterns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Extract entities using regex patterns"""
        entities = []
        
        for pattern_config in patterns:
            pattern = pattern_config['pattern']
            group = pattern_config.get('group', 0)
            confidence = pattern_config.get('confidence', 0.5)
            flags_str = pattern_config.get('flags', 'NONE')
            
            # Convert flags string to regex flags
            flags = 0
            if 'IGNORECASE' in flags_str:
                flags |= re.IGNORECASE
            if 'MULTILINE' in flags_str:
                flags |= re.MULTILINE
            if 'DOTALL' in flags_str:
                flags |= re.DOTALL
            
            try:
                matches = re.finditer(pattern, text, flags)
                
                for match in matches:
                    try:
                        value = match.group(group).strip()
                        start_pos = match.start(group) if group > 0 else match.start()
                        end_pos = match.end(group) if group > 0 else match.end()
                        
                        if value and len(value) > 1:  # Filter out single characters
                            entity = {
                                'entity_type': entity_type,
                                'value': value,
                                'position': start_pos,
                                'end_position': end_pos,
                                'confidence': confidence,
                                'pattern': pattern,
                                'context': self._extract_context(text, start_pos, end_pos),
                                'extraction_method': 'pattern'
                            }
                            entities.append(entity)
                    except (IndexError, AttributeError):
                        continue
                        
            except re.error:
                # Invalid regex pattern, skip
                continue
        
        return entities
    
    def _extract_by_gazetteer(self, text: str, entity_type: str, gazetteer: List[str]) -> List[Dict[str, Any]]:
        """Extract entities using gazetteer matching"""
        entities = []
        
        # Map entity types from gazetteer keys to our standard types
        type_mapping = {
            'currencies': 'currency',
            'financial_institutions': 'counterparty',
            'products': 'product',
            'risk_measures': 'risk_metric',
            'exception_types': 'exception_type'
        }
        
        mapped_type = type_mapping.get(entity_type, entity_type)
        
        for term in gazetteer:
            # Create case-insensitive pattern with word boundaries
            pattern = r'\b' + re.escape(term) + r'\b'
            
            matches = re.finditer(pattern, text, re.IGNORECASE)
            
            for match in matches:
                entity = {
                    'entity_type': mapped_type,
                    'value': match.group(),
                    'position': match.start(),
                    'end_position': match.end(),
                    'confidence': 0.8,  # Default confidence for gazetteer matches
                    'pattern': pattern,
                    'context': self._extract_context(text, match.start(), match.end()),
                    'extraction_method': 'gazetteer'
                }
                entities.append(entity)
        
        return entities
    
    def _extract_context(self, text: str, start_pos: int, end_pos: int, window_size: int = 50) -> str:
        """Extract context around an entity"""
        context_start = max(0, start_pos - window_size)
        context_end = min(len(text), end_pos + window_size)
        
        context = text[context_start:context_end].strip()
        
        # Add ellipsis if we truncated
        if context_start > 0:
            context = "..." + context
        if context_end < len(text):
            context = context + "..."
        
        return context
    
    def _post_process_entities(self, entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Post-process entities to remove duplicates and merge overlapping"""
        if not entities:
            return []
        
        # Sort by position
        sorted_entities = sorted(entities, key=lambda x: x['position'])
        
        # Group overlapping entities
        groups = []
        current_group = [sorted_entities[0]]
        
        for entity in sorted_entities[1:]:
            last_entity = current_group[-1]
            
            # Check for overlap
            if (entity['position'] <= last_entity['end_position'] and
                entity['end_position'] >= last_entity['position']):
                current_group.append(entity)
            else:
                groups.append(current_group)
                current_group = [entity]
        
        groups.append(current_group)
        
        # For each group, keep the highest confidence entity
        final_entities = []
        for group in groups:
            if len(group) == 1:
                final_entities.append(group[0])
            else:
                # Choose entity with highest confidence
                best_entity = max(group, key=lambda x: x['confidence'])
                
                # Merge information from other entities in group
                merged_methods = set(e['extraction_method'] for e in group)
                best_entity['extraction_methods'] = list(merged_methods)
                
                final_entities.append(best_entity)
        
        return final_entities
    
    def add_custom_pattern(self, entity_type: str, pattern: str, confidence: float = 0.7):
        """Add a custom extraction pattern"""
        if entity_type not in self.patterns:
            self.patterns[entity_type] = []
        
        pattern_config = {
            'pattern': pattern,
            'group': 1,
            'confidence': confidence,
            'flags': 'IGNORECASE'
        }
        
        self.patterns[entity_type].append(pattern_config)
    
    def update_confidence_threshold(self, threshold: float):
        """Update the confidence threshold for entity extraction"""
        self.confidence_threshold = max(0.0, min(1.0, threshold))
    
    def get_extraction_statistics(self, entities: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Get statistics about extracted entities"""
        if not entities:
            return {}
        
        stats = {
            'total_entities': len(entities),
            'entity_types': defaultdict(int),
            'extraction_methods': defaultdict(int),
            'confidence_distribution': {
                'high': 0,  # > 0.8
                'medium': 0,  # 0.6 - 0.8
                'low': 0  # < 0.6
            },
            'average_confidence': 0.0
        }
        
        total_confidence = 0
        
        for entity in entities:
            # Count by type
            stats['entity_types'][entity['entity_type']] += 1
            
            # Count by method
            stats['extraction_methods'][entity['extraction_method']] += 1
            
            # Confidence distribution
            confidence = entity['confidence']
            total_confidence += confidence
            
            if confidence > 0.8:
                stats['confidence_distribution']['high'] += 1
            elif confidence >= 0.6:
                stats['confidence_distribution']['medium'] += 1
            else:
                stats['confidence_distribution']['low'] += 1
        
        stats['average_confidence'] = total_confidence / len(entities)
        
        # Convert defaultdicts to regular dicts
        stats['entity_types'] = dict(stats['entity_types'])
        stats['extraction_methods'] = dict(stats['extraction_methods'])
        
        return stats
