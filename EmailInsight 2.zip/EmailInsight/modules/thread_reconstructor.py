from typing import Dict, List, Any, Optional
from datetime import datetime
import re
from collections import defaultdict, deque

class ThreadReconstructor:
    """Reconstructs email conversation threads using headers and subject analysis"""
    
    def __init__(self):
        self.thread_id_counter = 1
    
    def reconstruct_threads(self, processed_emails: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """
        Reconstruct conversation threads from processed email data
        
        Args:
            processed_emails: List of processed email dictionaries
            
        Returns:
            Dictionary mapping thread IDs to thread data
        """
        # Build message ID to email mapping
        message_id_map = {}
        emails_by_subject = defaultdict(list)
        
        for email_data in processed_emails:
            email_info = email_data['email_data']
            message_id = email_info.get('message_id', '')
            
            if message_id:
                message_id_map[message_id] = email_data
            
            # Group by thread topic for fallback threading
            thread_topic = email_info.get('thread_topic', email_info.get('subject', ''))
            if thread_topic:
                emails_by_subject[thread_topic].append(email_data)
        
        # Build threads using message references
        threads = {}
        processed_message_ids = set()
        
        # First pass: build threads using In-Reply-To and References
        for email_data in processed_emails:
            email_info = email_data['email_data']
            message_id = email_info.get('message_id', '')
            
            if message_id in processed_message_ids:
                continue
            
            thread_emails = self._build_thread_from_references(email_data, message_id_map)
            
            if thread_emails:
                thread_id = f"thread_{self.thread_id_counter}"
                self.thread_id_counter += 1
                
                # Sort emails chronologically
                thread_emails.sort(key=lambda x: x['email_data'].get('date', datetime.min))
                
                # Mark all emails in this thread as processed
                for thread_email in thread_emails:
                    thread_msg_id = thread_email['email_data'].get('message_id', '')
                    if thread_msg_id:
                        processed_message_ids.add(thread_msg_id)
                
                # Create thread metadata
                first_email = thread_emails[0]['email_data']
                thread_data = {
                    'thread_id': thread_id,
                    'subject': first_email.get('thread_topic', first_email.get('subject', '')),
                    'participants': self._extract_participants(thread_emails),
                    'start_date': first_email.get('date'),
                    'last_date': thread_emails[-1]['email_data'].get('date'),
                    'email_count': len(thread_emails),
                    'emails': thread_emails,
                    'thread_hierarchy': self._build_hierarchy(thread_emails)
                }
                
                threads[thread_id] = thread_data
        
        # Second pass: handle remaining emails using subject-based grouping
        remaining_emails = [
            email_data for email_data in processed_emails
            if email_data['email_data'].get('message_id', '') not in processed_message_ids
        ]
        
        for email_data in remaining_emails:
            email_info = email_data['email_data']
            thread_topic = email_info.get('thread_topic', email_info.get('subject', ''))
            
            # Try to find existing thread with same topic
            matching_thread = None
            for thread_id, thread_data in threads.items():
                if self._subjects_match(thread_data['subject'], thread_topic):
                    matching_thread = thread_id
                    break
            
            if matching_thread:
                # Add to existing thread
                threads[matching_thread]['emails'].append(email_data)
                threads[matching_thread]['email_count'] += 1
                
                # Update thread dates and participants
                email_date = email_info.get('date')
                if email_date:
                    if not threads[matching_thread]['last_date'] or email_date > threads[matching_thread]['last_date']:
                        threads[matching_thread]['last_date'] = email_date
                    if not threads[matching_thread]['start_date'] or email_date < threads[matching_thread]['start_date']:
                        threads[matching_thread]['start_date'] = email_date
                
                # Re-sort emails
                threads[matching_thread]['emails'].sort(key=lambda x: x['email_data'].get('date', datetime.min))
                
                # Update participants
                threads[matching_thread]['participants'] = self._extract_participants(threads[matching_thread]['emails'])
                
                # Rebuild hierarchy
                threads[matching_thread]['thread_hierarchy'] = self._build_hierarchy(threads[matching_thread]['emails'])
            else:
                # Create new single-email thread
                thread_id = f"thread_{self.thread_id_counter}"
                self.thread_id_counter += 1
                
                thread_data = {
                    'thread_id': thread_id,
                    'subject': thread_topic,
                    'participants': self._extract_participants([email_data]),
                    'start_date': email_info.get('date'),
                    'last_date': email_info.get('date'),
                    'email_count': 1,
                    'emails': [email_data],
                    'thread_hierarchy': self._build_hierarchy([email_data])
                }
                
                threads[thread_id] = thread_data
        
        return threads
    
    def _build_thread_from_references(self, root_email: Dict[str, Any], message_id_map: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Build thread starting from a root email using references"""
        thread_emails = []
        visited = set()
        
        # Use BFS to find all related emails
        queue = deque([root_email])
        
        while queue:
            current_email = queue.popleft()
            email_info = current_email['email_data']
            message_id = email_info.get('message_id', '')
            
            if message_id in visited:
                continue
            
            visited.add(message_id)
            thread_emails.append(current_email)
            
            # Find emails that reference this one
            for candidate_id, candidate_email in message_id_map.items():
                if candidate_id in visited:
                    continue
                
                candidate_info = candidate_email['email_data']
                in_reply_to = candidate_info.get('in_reply_to', '')
                references = candidate_info.get('references', [])
                
                # Check if this email is related
                if (in_reply_to == message_id or 
                    message_id in references or
                    self._is_subject_related(email_info.get('subject', ''), candidate_info.get('subject', ''))):
                    
                    queue.append(candidate_email)
            
            # Find emails this one references
            in_reply_to = email_info.get('in_reply_to', '')
            if in_reply_to and in_reply_to in message_id_map and in_reply_to not in visited:
                queue.append(message_id_map[in_reply_to])
            
            references = email_info.get('references', [])
            for ref_id in references:
                if ref_id in message_id_map and ref_id not in visited:
                    queue.append(message_id_map[ref_id])
        
        return thread_emails
    
    def _extract_participants(self, thread_emails: List[Dict[str, Any]]) -> List[str]:
        """Extract unique participants from thread emails"""
        participants = set()
        
        for email_data in thread_emails:
            email_info = email_data['email_data']
            
            # Add sender
            sender = email_info.get('sender', '')
            if sender:
                participants.add(sender)
            
            # Add recipients
            for recipient in email_info.get('recipients', []):
                participants.add(recipient)
            
            # Add CC
            for cc in email_info.get('cc', []):
                participants.add(cc)
        
        return sorted(list(participants))
    
    def _build_hierarchy(self, thread_emails: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Build hierarchical structure of thread"""
        hierarchy = {
            'root_emails': [],
            'reply_chains': [],
            'chronological_order': []
        }
        
        # Sort by date for chronological order
        sorted_emails = sorted(thread_emails, key=lambda x: x['email_data'].get('date', datetime.min))
        hierarchy['chronological_order'] = [
            {
                'message_id': email['email_data'].get('message_id', ''),
                'sender': email['email_data'].get('sender', ''),
                'date': email['email_data'].get('date'),
                'subject': email['email_data'].get('subject', '')
            }
            for email in sorted_emails
        ]
        
        # Identify root emails (no in-reply-to)
        for email_data in thread_emails:
            email_info = email_data['email_data']
            if not email_info.get('in_reply_to'):
                hierarchy['root_emails'].append({
                    'message_id': email_info.get('message_id', ''),
                    'sender': email_info.get('sender', ''),
                    'subject': email_info.get('subject', ''),
                    'date': email_info.get('date')
                })
        
        # Build reply chains
        message_to_email = {
            email['email_data'].get('message_id', ''): email 
            for email in thread_emails 
            if email['email_data'].get('message_id')
        }
        
        for email_data in thread_emails:
            email_info = email_data['email_data']
            in_reply_to = email_info.get('in_reply_to', '')
            
            if in_reply_to and in_reply_to in message_to_email:
                parent_email = message_to_email[in_reply_to]['email_data']
                hierarchy['reply_chains'].append({
                    'parent': {
                        'message_id': parent_email.get('message_id', ''),
                        'sender': parent_email.get('sender', ''),
                        'subject': parent_email.get('subject', '')
                    },
                    'reply': {
                        'message_id': email_info.get('message_id', ''),
                        'sender': email_info.get('sender', ''),
                        'subject': email_info.get('subject', '')
                    }
                })
        
        return hierarchy
    
    def _subjects_match(self, subject1: str, subject2: str) -> bool:
        """Check if two subjects belong to the same thread"""
        if not subject1 or not subject2:
            return False
        
        # Normalize subjects
        norm_subject1 = self._normalize_subject(subject1)
        norm_subject2 = self._normalize_subject(subject2)
        
        return norm_subject1 == norm_subject2
    
    def _is_subject_related(self, subject1: str, subject2: str) -> bool:
        """Check if subjects are related (more lenient than exact match)"""
        if not subject1 or not subject2:
            return False
        
        norm_subject1 = self._normalize_subject(subject1)
        norm_subject2 = self._normalize_subject(subject2)
        
        # Check for substring relationship
        return (norm_subject1 in norm_subject2 or 
                norm_subject2 in norm_subject1 or
                self._calculate_similarity(norm_subject1, norm_subject2) > 0.8)
    
    def _normalize_subject(self, subject: str) -> str:
        """Normalize subject for comparison"""
        if not subject:
            return ''
        
        # Remove common prefixes and brackets
        normalized = re.sub(r'^(Re:|RE:|Fw:|FW:|Fwd:|FWD:)\s*', '', subject, flags=re.IGNORECASE)
        normalized = re.sub(r'^\[.*?\]\s*', '', normalized)
        normalized = normalized.strip().lower()
        
        return normalized
    
    def _calculate_similarity(self, str1: str, str2: str) -> float:
        """Calculate simple similarity between two strings"""
        if not str1 or not str2:
            return 0.0
        
        # Simple word-based similarity
        words1 = set(str1.split())
        words2 = set(str2.split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union) if union else 0.0
