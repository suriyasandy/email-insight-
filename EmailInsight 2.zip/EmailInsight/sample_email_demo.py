#!/usr/bin/env python3
"""
Sample Email Demo - Creates realistic test email data for the Financial Trade Email Surveillance System
"""

from datetime import datetime, timedelta
import json
import sys
import os

# Add modules to path
sys.path.append('.')

from modules.entity_extractor import EntityExtractor
from modules.summarizer import EmailSummarizer
from modules.provenance_tracker import ProvenanceTracker
from modules.thread_reconstructor import ThreadReconstructor

def create_sample_trade_email():
    """Create a realistic sample trade email with financial content"""
    
    sample_email = {
        'sender': 'john.trader@globalbank.com',
        'recipients': ['risk.team@globalbank.com', 'operations@globalbank.com'],
        'cc': ['compliance@globalbank.com'],
        'bcc': [],
        'subject': 'URGENT: Trade Break - FX Forward Settlement Issue - Trade ID: GBF240830001',
        'date': datetime.now() - timedelta(hours=2),
        'body': """Dear Risk and Operations Team,

We have identified a critical trade break for the following FX Forward transaction that requires immediate attention:

Trade Details:
- Trade ID: GBF240830001
- Product: FX Forward EUR/USD
- Notional Amount: EUR 25,000,000
- Counterparty: Deutsche Bank AG
- Trade Date: 30/08/2024
- Settlement Date: 02/09/2024
- Rate: 1.1045
- Trader: Sarah Johnson
- Portfolio: FX_DESK_EMEA
- Book: LONDON_FX_001

Issue Description:
Settlement instruction mismatch detected. Our system shows settlement amount as USD 27,612,500 but counterparty confirmation indicates USD 27,615,000. This represents a variance of USD 2,500.

Risk Metrics:
- PV01: +125,000
- Delta: 0.85
- VaR: EUR 450,000
- Credit Exposure: EUR 2,100,000

This threshold breach requires immediate investigation as it exceeds our USD 1,000 variance limit for FX settlements.

Required Actions:
1. Verify trade confirmation details with Deutsche Bank
2. Review settlement instructions in SWIFT system
3. Escalate to Legal if discrepancy cannot be resolved by EOD
4. Update risk systems with corrected exposure figures

Please confirm receipt and provide status update by 15:00 GMT today.

Regards,
John Trader
FX Trading Desk
Global Bank Ltd
Phone: +44 20 7123 4567
Email: john.trader@globalbank.com

CONFIDENTIAL: This email contains sensitive trading information and is intended only for authorized personnel.
""",
        'html_body': '',
        'attachments': [
            {
                'filename': 'trade_confirmation_GBF240830001.pdf',
                'size': 245760,
                'content_type': 'application/pdf',
                'is_embedded': False
            }
        ],
        'headers': {
            'Message-ID': '<20240830120000.GBF240830001@globalbank.com>',
            'In-Reply-To': '',
            'References': ''
        },
        'message_id': '20240830120000.GBF240830001@globalbank.com',
        'in_reply_to': '',
        'references': [],
        'thread_topic': 'Trade Break - FX Forward Settlement Issue - Trade ID: GBF240830001',
        'importance': 'high',
        'read_receipt': True,
        'tables': [],
        'structured_content': {
            'trade_blocks': [
                'Trade ID: GBF240830001',
                'Trade Date: 30/08/2024',
                'Settlement Date: 02/09/2024'
            ],
            'numbered_lists': [
                'Verify trade confirmation details with Deutsche Bank',
                'Review settlement instructions in SWIFT system',
                'Escalate to Legal if discrepancy cannot be resolved by EOD',
                'Update risk systems with corrected exposure figures'
            ],
            'bullet_points': [],
            'key_value_pairs': [
                {'key': 'Trade ID', 'value': 'GBF240830001'},
                {'key': 'Product', 'value': 'FX Forward EUR/USD'},
                {'key': 'Notional Amount', 'value': 'EUR 25,000,000'},
                {'key': 'Counterparty', 'value': 'Deutsche Bank AG'},
                {'key': 'Rate', 'value': '1.1045'},
                {'key': 'Trader', 'value': 'Sarah Johnson'},
                {'key': 'Portfolio', 'value': 'FX_DESK_EMEA'},
                {'key': 'PV01', 'value': '+125,000'},
                {'key': 'Delta', 'value': '0.85'},
                {'key': 'VaR', 'value': 'EUR 450,000'}
            ]
        }
    }
    
    return sample_email

def create_followup_email():
    """Create a follow-up email for the same thread"""
    
    followup_email = {
        'sender': 'risk.team@globalbank.com',
        'recipients': ['john.trader@globalbank.com'],
        'cc': ['operations@globalbank.com', 'compliance@globalbank.com'],
        'bcc': [],
        'subject': 'Re: URGENT: Trade Break - FX Forward Settlement Issue - Trade ID: GBF240830001',
        'date': datetime.now() - timedelta(minutes=30),
        'body': """John,

Thank you for the urgent notification. Risk team has reviewed the trade break for GBF240830001.

Status Update:
- Contacted Deutsche Bank Operations - confirmed they have USD 27,615,000 in their system
- Root cause identified: Rate difference in 4th decimal place (1.1045 vs 1.1046)
- This appears to be a rounding discrepancy in our trade capture system

Resolution Steps:
1. Operations team to amend our settlement instruction to USD 27,615,000
2. Trade booking system will be updated with correct rate: 1.1046
3. Risk systems updated - new VaR: EUR 451,200 (+EUR 1,200 adjustment)

Compliance Note:
This incident will be logged as a minor operational risk event. No regulatory reporting required as variance is below EUR 10,000 threshold.

Trade details now reconciled. Settlement confirmed for 02/09/2024 COB.

Best regards,
Risk Management Team
Global Bank Ltd

---
Original Message Details:
Trade ID: GBF240830001
Issue: Settlement amount variance USD 2,500
Status: RESOLVED
Resolution Time: 1.5 hours
""",
        'html_body': '',
        'attachments': [],
        'headers': {
            'Message-ID': '<20240830133000.RESPONSE.GBF240830001@globalbank.com>',
            'In-Reply-To': '<20240830120000.GBF240830001@globalbank.com>',
            'References': '<20240830120000.GBF240830001@globalbank.com>'
        },
        'message_id': '20240830133000.RESPONSE.GBF240830001@globalbank.com',
        'in_reply_to': '20240830120000.GBF240830001@globalbank.com',
        'references': ['20240830120000.GBF240830001@globalbank.com'],
        'thread_topic': 'Trade Break - FX Forward Settlement Issue - Trade ID: GBF240830001',
        'importance': 'normal',
        'read_receipt': False,
        'tables': [],
        'structured_content': {
            'trade_blocks': [
                'Trade ID: GBF240830001'
            ],
            'numbered_lists': [
                'Operations team to amend our settlement instruction to USD 27,615,000',
                'Trade booking system will be updated with correct rate: 1.1046',
                'Risk systems updated - new VaR: EUR 451,200 (+EUR 1,200 adjustment)'
            ],
            'bullet_points': [],
            'key_value_pairs': [
                {'key': 'Trade ID', 'value': 'GBF240830001'},
                {'key': 'Status', 'value': 'RESOLVED'},
                {'key': 'Resolution Time', 'value': '1.5 hours'},
                {'key': 'Correct Rate', 'value': '1.1046'},
                {'key': 'New VaR', 'value': 'EUR 451,200'}
            ]
        }
    }
    
    return followup_email

def process_sample_emails():
    """Process the sample emails through the surveillance system"""
    
    print("🏦 Financial Trade Email Surveillance System - Sample Demo")
    print("=" * 60)
    
    # Initialize modules
    entity_extractor = EntityExtractor()
    summarizer = EmailSummarizer()
    provenance_tracker = ProvenanceTracker()
    thread_reconstructor = ThreadReconstructor()
    
    # Create sample emails
    email1 = create_sample_trade_email()
    email2 = create_followup_email()
    
    print("\n📧 SAMPLE EMAIL 1 - Initial Trade Break Alert")
    print("-" * 50)
    print(f"From: {email1['sender']}")
    print(f"To: {', '.join(email1['recipients'])}")
    print(f"Subject: {email1['subject']}")
    print(f"Date: {email1['date'].strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Body Preview: {email1['body'][:200]}...")
    
    print("\n📧 SAMPLE EMAIL 2 - Follow-up Response")
    print("-" * 50)
    print(f"From: {email2['sender']}")
    print(f"To: {', '.join(email2['recipients'])}")
    print(f"Subject: {email2['subject']}")
    print(f"Date: {email2['date'].strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Body Preview: {email2['body'][:200]}...")
    
    # Process emails through the system
    processed_emails = []
    
    for i, email_data in enumerate([email1, email2], 1):
        print(f"\n🔍 PROCESSING EMAIL {i}")
        print("-" * 30)
        
        # Extract entities
        entities = entity_extractor.extract_entities(email_data['body'])
        print(f"✓ Extracted {len(entities)} entities")
        
        # Create provenance record
        provenance_data = provenance_tracker.create_provenance_record(
            email_data, entities, f"sample_email_{i}.msg"
        )
        print(f"✓ Created provenance record: {provenance_data['record_id']}")
        
        # Store processed data
        processed_data = {
            'filename': f'sample_email_{i}.msg',
            'email_data': email_data,
            'entities': entities,
            'provenance': provenance_data
        }
        processed_emails.append(processed_data)
        
        # Show some extracted entities
        print("\n📊 Key Entities Extracted:")
        for entity in entities[:5]:  # Show first 5 entities
            print(f"   • {entity['entity_type']}: {entity['value']} (confidence: {entity['confidence']:.2f})")
        if len(entities) > 5:
            print(f"   ... and {len(entities) - 5} more entities")
    
    # Reconstruct thread
    print(f"\n🧵 THREAD RECONSTRUCTION")
    print("-" * 30)
    threads = thread_reconstructor.reconstruct_threads(processed_emails)
    print(f"✓ Reconstructed {len(threads)} conversation thread(s)")
    
    # Generate summary for each thread
    for thread_id, thread_data in threads.items():
        print(f"\n📋 THREAD SUMMARY - {thread_id}")
        print("-" * 40)
        
        summary = summarizer.generate_thread_summary(thread_data)
        thread_data['summary'] = summary
        
        print(f"Thread Subject: {thread_data['subject']}")
        print(f"Participants: {', '.join(thread_data['participants'])}")
        print(f"Email Count: {thread_data['email_count']}")
        print(f"Time Span: {thread_data['start_date'].strftime('%Y-%m-%d %H:%M')} to {thread_data['last_date'].strftime('%Y-%m-%d %H:%M')}")
        
        print(f"\n💬 AI-Generated Summary:")
        print(f"   {summary['summary_text'][:300]}...")
        
        print(f"\n🔑 Key Points:")
        for i, point in enumerate(summary['key_points'][:3], 1):
            print(f"   {i}. {point['text'][:100]}... (by {point['sender']})")
        
        print(f"\n⚠️ Critical Entities:")
        for entity in summary['critical_entities'][:5]:
            print(f"   • {entity['entity_type']}: {entity['value']} (importance: {entity['importance_score']:.1f})")
    
    print(f"\n✅ PROCESSING COMPLETE")
    print(f"📊 Final Statistics:")
    print(f"   • Total Emails Processed: {len(processed_emails)}")
    print(f"   • Total Entities Extracted: {sum(len(email['entities']) for email in processed_emails)}")
    print(f"   • Threads Reconstructed: {len(threads)}")
    print(f"   • Summaries Generated: {sum(1 for thread in threads.values() if thread.get('summary'))}")
    
    return threads

if __name__ == "__main__":
    threads = process_sample_emails()
    
    # Save the sample data for use in the Streamlit app
    sample_data = {
        'threads': threads,
        'processing_timestamp': datetime.now().isoformat(),
        'sample_data': True
    }
    
    with open('sample_processed_data.json', 'w') as f:
        json.dump(sample_data, f, indent=2, default=str)
    
    print(f"\n💾 Sample data saved to 'sample_processed_data.json'")
    print("🌐 You can now load this data in the Streamlit application!")