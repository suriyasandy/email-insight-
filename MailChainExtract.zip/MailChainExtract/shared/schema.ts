import { z } from "zod";

// Email processing schemas for rule-based extraction
export const extractedAttributeSchema = z.object({
  id: z.string(),
  type: z.enum(["email", "phone", "date", "amount", "name", "address", "custom"]),
  value: z.string(),
  confidence: z.number().min(0).max(1),
  position: z.object({
    start: z.number(),
    end: z.number()
  }),
  context: z.string().optional() // surrounding text
});

export const emailMetadataSchema = z.object({
  sender: z.string(),
  recipient: z.string().array(),
  subject: z.string(),
  date: z.string(),
  messageId: z.string().optional(),
  inReplyTo: z.string().optional()
});

export const extractionRuleSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: z.enum(["email", "phone", "date", "amount", "name", "address", "custom"]),
  pattern: z.string(), // regex pattern
  enabled: z.boolean(),
  description: z.string().optional()
});

export const emailProcessingResultSchema = z.object({
  id: z.string(),
  fileName: z.string(),
  fileSize: z.number(),
  processedAt: z.string(),
  metadata: emailMetadataSchema,
  extractedAttributes: extractedAttributeSchema.array(),
  rawContent: z.string(),
  threadPosition: z.number().optional() // position in email chain
});

export const extractionSessionSchema = z.object({
  id: z.string(),
  name: z.string(),
  createdAt: z.string(),
  filesProcessed: z.number(),
  results: emailProcessingResultSchema.array(),
  activeRules: extractionRuleSchema.array()
});

export type ExtractedAttribute = z.infer<typeof extractedAttributeSchema>;
export type EmailMetadata = z.infer<typeof emailMetadataSchema>;
export type ExtractionRule = z.infer<typeof extractionRuleSchema>;
export type EmailProcessingResult = z.infer<typeof emailProcessingResultSchema>;
export type ExtractionSession = z.infer<typeof extractionSessionSchema>;
