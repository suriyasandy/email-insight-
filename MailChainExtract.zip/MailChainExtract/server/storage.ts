import { type ExtractionSession, type EmailProcessingResult, type ExtractionRule } from "@shared/schema";
import { randomUUID } from "crypto";

// Storage interface for email extraction data
export interface IStorage {
  // Session management
  createSession(name: string): Promise<ExtractionSession>;
  getSession(id: string): Promise<ExtractionSession | undefined>;
  updateSession(session: ExtractionSession): Promise<ExtractionSession>;
  
  // Results storage
  saveResults(sessionId: string, results: EmailProcessingResult[]): Promise<void>;
  getResults(sessionId: string): Promise<EmailProcessingResult[]>;
  
  // Rules management
  saveRules(rules: ExtractionRule[]): Promise<void>;
  getRules(): Promise<ExtractionRule[]>;
}

export class MemStorage implements IStorage {
  private sessions: Map<string, ExtractionSession>;
  private results: Map<string, EmailProcessingResult[]>;
  private rules: ExtractionRule[];

  constructor() {
    this.sessions = new Map();
    this.results = new Map();
    this.rules = [];
  }

  async createSession(name: string): Promise<ExtractionSession> {
    const session: ExtractionSession = {
      id: randomUUID(),
      name,
      createdAt: new Date().toISOString(),
      filesProcessed: 0,
      results: [],
      activeRules: this.rules.filter(r => r.enabled)
    };
    this.sessions.set(session.id, session);
    return session;
  }

  async getSession(id: string): Promise<ExtractionSession | undefined> {
    return this.sessions.get(id);
  }

  async updateSession(session: ExtractionSession): Promise<ExtractionSession> {
    this.sessions.set(session.id, session);
    return session;
  }

  async saveResults(sessionId: string, results: EmailProcessingResult[]): Promise<void> {
    this.results.set(sessionId, results);
  }

  async getResults(sessionId: string): Promise<EmailProcessingResult[]> {
    return this.results.get(sessionId) || [];
  }

  async saveRules(rules: ExtractionRule[]): Promise<void> {
    this.rules = rules;
  }

  async getRules(): Promise<ExtractionRule[]> {
    return this.rules;
  }
}

export const storage = new MemStorage();
