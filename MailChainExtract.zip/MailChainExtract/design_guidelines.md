# Email Extractor Design Guidelines

## Design Approach
**Utility-Focused Design System Approach** - This is a productivity tool that prioritizes efficiency and data processing workflows. Using a clean, professional interface based on modern design system principles with minimal visual distractions.

## Core Design Elements

### Color Palette
- **Primary**: 220 15% 15% (Dark charcoal for headers and primary elements)
- **Background**: 0 0% 98% (Light neutral background)
- **Surface**: 0 0% 100% (Pure white for cards and containers)
- **Border**: 220 13% 91% (Subtle gray borders)
- **Text Primary**: 220 9% 46% (Dark gray for main text)
- **Text Secondary**: 220 9% 60% (Medium gray for secondary text)
- **Success**: 142 71% 45% (Green for successful extractions)
- **Warning**: 38 92% 50% (Orange for processing states)
- **Error**: 0 84% 60% (Red for errors)

### Typography
- **Primary Font**: Inter (Google Fonts) - Clean, readable sans-serif
- **Monospace**: JetBrains Mono (Google Fonts) - For extracted data display
- **Hierarchy**: Use font weights 400, 500, 600 with sizes ranging from text-sm to text-2xl

### Layout System
**Tailwind Spacing Primitives**: Standardize on units of 2, 4, 6, 8, 12, 16
- Container padding: p-6 or p-8
- Component spacing: gap-4 or gap-6
- Margins: m-4, m-6, m-8
- Grid gaps: gap-4

### Component Library

#### Core Components
- **Upload Zone**: Large dashed border area with drag-and-drop styling
- **Data Cards**: Clean white containers with subtle shadows for displaying extracted attributes
- **Progress Indicators**: Simple linear progress bars for processing status
- **Result Tables**: Structured data display with alternating row colors
- **Action Buttons**: Primary (solid) and secondary (outline) button variants

#### Navigation
- **Header**: Minimal top navigation with app title and settings
- **Sidebar** (if needed): Collapsible panel for extraction templates
- **Breadcrumbs**: Simple text-based navigation for multi-step processes

#### Forms
- **File Upload**: Prominent drop zone with clear file type indicators
- **Configuration Forms**: Clean form layouts with grouped related fields
- **Filter Controls**: Compact search and filter interfaces

#### Data Displays
- **Extraction Results**: Tabular format with clear column headers
- **Confidence Indicators**: Simple percentage or color-coded confidence levels
- **Preview Panels**: Side-by-side email content and extracted data view

#### Overlays
- **Processing Modal**: Simple spinner with progress text
- **Export Dialog**: Clean modal for choosing export formats
- **Settings Panel**: Slide-over panel for configuration options

### Visual Hierarchy
- **High Contrast**: Use bold typography and spacing for primary actions
- **Grouped Information**: Card-based layouts to separate different data sets
- **Scan-friendly**: Left-aligned text with consistent spacing for easy scanning
- **Status Communication**: Clear visual indicators for processing states and results

### Interaction Design
- **Minimal Animations**: Subtle fade-ins for state changes only
- **Immediate Feedback**: Instant visual confirmation for user actions
- **Clear Loading States**: Simple spinners and progress indicators
- **Error Handling**: Inline error messages with actionable guidance

This design prioritizes data clarity, processing efficiency, and professional appearance suitable for a business productivity tool focused on email data extraction without NLP dependencies.