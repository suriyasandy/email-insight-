import { useState } from 'react';
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "./hooks/useTheme";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Settings, Table, Mail } from 'lucide-react';
import FileUploadZone from './components/FileUploadZone';
import EmailProcessor from './components/EmailProcessor';
import ResultsTable from './components/ResultsTable';
import ExtractionRules from './components/ExtractionRules';
import ThemeToggle from './components/ThemeToggle';
import type { EmailProcessingResult, ExtractionRule } from '@shared/schema';

function EmailExtractorApp() {
  const [files, setFiles] = useState<File[]>([]);
  const [results, setResults] = useState<EmailProcessingResult[]>([]);
  const [activeTab, setActiveTab] = useState('upload');
  
  // //todo: remove mock functionality - default extraction rules
  const [extractionRules, setExtractionRules] = useState<ExtractionRule[]>([
    {
      id: '1',
      name: 'Email Addresses',
      type: 'email',
      pattern: '[\\w\\.-]+@[\\w\\.-]+\\.[\\w]+',
      enabled: true,
      description: 'Standard email address pattern'
    },
    {
      id: '2',
      name: 'US Phone Numbers', 
      type: 'phone',
      pattern: '(?:\\+?1[-. ]?)?\\(?[0-9]{3}\\)?[-. ]?[0-9]{3}[-. ]?[0-9]{4}',
      enabled: true,
      description: 'Matches US phone number formats'
    },
    {
      id: '3',
      name: 'Dollar Amounts',
      type: 'amount', 
      pattern: '\\$[\\d,]+(?:\\.[\\d]{2})?',
      enabled: true,
      description: 'Currency amounts in USD'
    },
    {
      id: '4',
      name: 'Dates',
      type: 'date',
      pattern: '\\b(?:\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}|\\w+\\s+\\d{1,2},?\\s+\\d{4})\\b',
      enabled: true,
      description: 'Common date formats'
    }
  ]);

  const handleFilesSelected = (selectedFiles: File[]) => {
    setFiles(selectedFiles);
    setActiveTab('process');
  };

  const handleProcessingComplete = (processedResults: EmailProcessingResult[]) => {
    setResults(processedResults);
    setActiveTab('results');
  };

  const handleExport = (format: 'csv' | 'json') => {
    console.log(`Exporting ${results.length} results as ${format}`);
    // //todo: remove mock functionality - implement actual export
    const allAttributes = results.flatMap(result => 
      result.extractedAttributes.map(attr => ({
        fileName: result.fileName,
        sender: result.metadata.sender,
        subject: result.metadata.subject,
        type: attr.type,
        value: attr.value,
        confidence: attr.confidence,
        context: attr.context
      }))
    );
    
    if (format === 'csv') {
      const csvHeader = 'File Name,Sender,Subject,Type,Value,Confidence,Context\n';
      const csvRows = allAttributes.map(attr => 
        `"${attr.fileName}","${attr.sender}","${attr.subject}","${attr.type}","${attr.value}","${attr.confidence}","${attr.context || ''}"`
      ).join('\n');
      const csvContent = csvHeader + csvRows;
      
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `email-extraction-results-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } else {
      const jsonContent = JSON.stringify({
        exportDate: new Date().toISOString(),
        totalResults: results.length,
        totalAttributes: allAttributes.length,
        results: results
      }, null, 2);
      
      const blob = new Blob([jsonContent], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `email-extraction-results-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  };

  const resetWorkflow = () => {
    setFiles([]);
    setResults([]);
    setActiveTab('upload');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-lg bg-primary text-primary-foreground">
                <Mail className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-semibold">Email Extractor</h1>
                <p className="text-sm text-muted-foreground">Rule-based attribute extraction from email chains</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              {results.length > 0 && (
                <div className="text-sm text-muted-foreground">
                  {results.reduce((sum, r) => sum + r.extractedAttributes.length, 0)} attributes extracted
                </div>
              )}
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Tab Navigation */}
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="upload" className="flex items-center space-x-2" data-testid="tab-upload">
              <FileText className="h-4 w-4" />
              <span>Upload</span>
            </TabsTrigger>
            
            <TabsTrigger 
              value="process" 
              className="flex items-center space-x-2"
              disabled={files.length === 0}
              data-testid="tab-process"
            >
              <Settings className="h-4 w-4" />
              <span>Process</span>
            </TabsTrigger>
            
            <TabsTrigger 
              value="results" 
              className="flex items-center space-x-2"
              disabled={results.length === 0}
              data-testid="tab-results"
            >
              <Table className="h-4 w-4" />
              <span>Results</span>
            </TabsTrigger>
            
            <TabsTrigger value="rules" className="flex items-center space-x-2" data-testid="tab-rules">
              <Settings className="h-4 w-4" />
              <span>Rules</span>
            </TabsTrigger>
          </TabsList>

          {/* Upload Tab */}
          <TabsContent value="upload" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Upload Email Files</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Select or drag email files (.eml, .msg, .txt) to extract attributes using configured patterns
                </p>
              </CardHeader>
              <CardContent>
                <FileUploadZone
                  onFilesSelected={handleFilesSelected}
                  acceptedTypes={['.eml', '.msg', '.txt']}
                  maxFiles={10}
                />
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="text-center p-4">
                <div className="text-2xl font-bold text-primary">{extractionRules.filter(r => r.enabled).length}</div>
                <div className="text-sm text-muted-foreground">Active Rules</div>
              </Card>
              <Card className="text-center p-4">
                <div className="text-2xl font-bold text-chart-1">{files.length}</div>
                <div className="text-sm text-muted-foreground">Files Ready</div>
              </Card>
              <Card className="text-center p-4">
                <div className="text-2xl font-bold text-chart-2">{results.reduce((sum, r) => sum + r.extractedAttributes.length, 0)}</div>
                <div className="text-sm text-muted-foreground">Total Extracted</div>
              </Card>
            </div>
          </TabsContent>

          {/* Processing Tab */}
          <TabsContent value="process" className="space-y-6">
            <EmailProcessor
              files={files}
              onProcessingComplete={handleProcessingComplete}
            />
            
            {files.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Processing Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Files queued:</span>
                      <span className="font-medium">{files.length}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Active rules:</span>
                      <span className="font-medium">{extractionRules.filter(r => r.enabled).length}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Expected patterns:</span>
                      <span className="font-medium">
                        {extractionRules.filter(r => r.enabled).map(r => r.type).join(', ')}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Results Tab */}
          <TabsContent value="results" className="space-y-6">
            {results.length > 0 ? (
              <ResultsTable 
                results={results}
                onExport={handleExport}
              />
            ) : (
              <Card className="text-center py-12">
                <CardContent>
                  <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-medium mb-2">No results yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Upload and process email files to see extracted attributes here
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Rules Tab */}
          <TabsContent value="rules" className="space-y-6">
            <ExtractionRules
              rules={extractionRules}
              onRulesChange={setExtractionRules}
            />

            <Card>
              <CardHeader>
                <CardTitle>Pattern Matching</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <p className="text-muted-foreground">
                    This tool uses regular expressions (regex) to identify and extract specific patterns from email content.
                    Each rule defines a pattern that will be searched for across all uploaded files.
                  </p>
                  <Separator />
                  <div className="space-y-2">
                    <h4 className="font-medium">Built-in Pattern Types:</h4>
                    <ul className="space-y-1 text-muted-foreground ml-4">
                      <li>• <strong>Email:</strong> Standard email address format</li>
                      <li>• <strong>Phone:</strong> US phone number formats with various separators</li>
                      <li>• <strong>Amount:</strong> Currency amounts in dollar format</li>
                      <li>• <strong>Date:</strong> Common date formats (MM/DD/YYYY, Month DD, YYYY)</li>
                      <li>• <strong>Name:</strong> Capitalized word sequences (proper nouns)</li>
                      <li>• <strong>Address:</strong> Street addresses with zip codes</li>
                      <li>• <strong>Custom:</strong> User-defined regex patterns</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <EmailExtractorApp />
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
