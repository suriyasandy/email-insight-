import { useState, useMemo } from 'react';
import { Search, Filter, Eye, Download, Copy, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Separator } from '@/components/ui/separator';
import type { EmailProcessingResult, ExtractedAttribute } from '@shared/schema';

interface ResultsTableProps {
  results: EmailProcessingResult[];
  onExport: (format: 'csv' | 'json') => void;
}

export default function ResultsTable({ results, onExport }: ResultsTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [selectedResult, setSelectedResult] = useState<EmailProcessingResult | null>(null);

  // Flatten all attributes from all results for table display
  const allAttributes = useMemo(() => {
    return results.flatMap(result => 
      result.extractedAttributes.map(attr => ({
        ...attr,
        fileName: result.fileName,
        sender: result.metadata.sender,
        subject: result.metadata.subject,
        processedAt: result.processedAt
      }))
    );
  }, [results]);

  // Filter attributes based on search and type
  const filteredAttributes = useMemo(() => {
    return allAttributes.filter(attr => {
      const matchesSearch = !searchTerm || 
        attr.value.toLowerCase().includes(searchTerm.toLowerCase()) ||
        attr.fileName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        attr.sender.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesType = typeFilter === 'all' || attr.type === typeFilter;
      
      return matchesSearch && matchesType;
    });
  }, [allAttributes, searchTerm, typeFilter]);

  const getTypeColor = (type: ExtractedAttribute['type']) => {
    const colors = {
      email: 'bg-blue-100 text-blue-800',
      phone: 'bg-green-100 text-green-800',
      date: 'bg-purple-100 text-purple-800',
      amount: 'bg-yellow-100 text-yellow-800',
      name: 'bg-pink-100 text-pink-800',
      address: 'bg-orange-100 text-orange-800',
      custom: 'bg-gray-100 text-gray-800'
    };
    return colors[type];
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    console.log('Copied to clipboard:', text);
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'text-chart-1';
    if (confidence >= 0.6) return 'text-chart-2';
    return 'text-chart-5';
  };

  return (
    <Card data-testid="results-table">
      <CardHeader className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <CardTitle className="text-lg">Extraction Results</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Found {filteredAttributes.length} attributes across {results.length} files
            </p>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onExport('csv')}
              data-testid="button-export-csv"
            >
              <Download className="h-4 w-4 mr-2" />
              CSV
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onExport('json')}
              data-testid="button-export-json"
            >
              <Download className="h-4 w-4 mr-2" />
              JSON
            </Button>
          </div>
        </div>
        
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search attributes, files, or senders..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
              data-testid="input-search"
            />
          </div>
          
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-40" data-testid="select-type-filter">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="phone">Phone</SelectItem>
              <SelectItem value="date">Date</SelectItem>
              <SelectItem value="amount">Amount</SelectItem>
              <SelectItem value="name">Name</SelectItem>
              <SelectItem value="address">Address</SelectItem>
              <SelectItem value="custom">Custom</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      
      <Separator />
      
      <CardContent className="p-0">
        {filteredAttributes.length === 0 ? (
          <div className="text-center py-8" data-testid="no-results">
            <p className="text-muted-foreground">No attributes found matching your criteria</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px]">Type</TableHead>
                  <TableHead className="min-w-[200px]">Value</TableHead>
                  <TableHead className="w-[100px]">Confidence</TableHead>
                  <TableHead className="min-w-[150px]">Source File</TableHead>
                  <TableHead className="min-w-[180px]">Sender</TableHead>
                  <TableHead className="min-w-[200px]">Context</TableHead>
                  <TableHead className="w-[100px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAttributes.map((attribute, index) => (
                  <TableRow 
                    key={`${attribute.id}-${index}`} 
                    className="hover-elevate"
                    data-testid={`row-attribute-${index}`}
                  >
                    <TableCell>
                      <Badge 
                        variant="secondary"
                        className={`text-xs ${getTypeColor(attribute.type)}`}
                        data-testid={`badge-type-${attribute.type}`}
                      >
                        {attribute.type}
                      </Badge>
                    </TableCell>
                    
                    <TableCell className="font-medium">
                      <div className="flex items-center space-x-2">
                        <span className="font-mono text-sm" data-testid={`text-value-${index}`}>
                          {attribute.value}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(attribute.value)}
                          className="h-6 w-6 p-0"
                          data-testid={`button-copy-${index}`}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    </TableCell>
                    
                    <TableCell>
                      <span 
                        className={`font-medium text-sm ${getConfidenceColor(attribute.confidence)}`}
                        data-testid={`text-confidence-${index}`}
                      >
                        {(attribute.confidence * 100).toFixed(0)}%
                      </span>
                    </TableCell>
                    
                    <TableCell>
                      <span className="text-sm truncate" data-testid={`text-filename-${index}`}>
                        {attribute.fileName}
                      </span>
                    </TableCell>
                    
                    <TableCell>
                      <span className="text-sm text-muted-foreground font-mono" data-testid={`text-sender-${index}`}>
                        {attribute.sender}
                      </span>
                    </TableCell>
                    
                    <TableCell>
                      <span className="text-sm text-muted-foreground line-clamp-2" data-testid={`text-context-${index}`}>
                        {attribute.context || 'No context available'}
                      </span>
                    </TableCell>
                    
                    <TableCell>
                      <div className="flex space-x-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => console.log('View details for:', attribute.id)}
                          className="h-8 w-8 p-0"
                          data-testid={`button-view-${index}`}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        
                        {(attribute.type === 'email' || attribute.type === 'phone') && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              const action = attribute.type === 'email' ? `mailto:${attribute.value}` : `tel:${attribute.value}`;
                              window.open(action, '_blank');
                            }}
                            className="h-8 w-8 p-0"
                            data-testid={`button-open-${index}`}
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}