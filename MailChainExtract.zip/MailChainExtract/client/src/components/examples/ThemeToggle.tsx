import ThemeToggle from '../ThemeToggle';
import { ThemeProvider } from '../../hooks/useTheme';

export default function ThemeToggleExample() {
  return (
    <ThemeProvider>
      <div className="p-6 flex items-center space-x-4">
        <span className="text-sm text-muted-foreground">Theme Toggle:</span>
        <ThemeToggle />
      </div>
    </ThemeProvider>
  );
}