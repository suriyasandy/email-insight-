import { useState } from 'react';
import ExtractionRules from '../ExtractionRules';
import type { ExtractionRule } from '@shared/schema';

export default function ExtractionRulesExample() {
  // //todo: remove mock functionality - mock rules for demo
  const [rules, setRules] = useState<ExtractionRule[]>([
    {
      id: '1',
      name: 'Email Addresses',
      type: 'email',
      pattern: '[\\w\\.-]+@[\\w\\.-]+\\.[\\w]+',
      enabled: true,
      description: 'Standard email address pattern'
    },
    {
      id: '2',
      name: 'US Phone Numbers',
      type: 'phone',
      pattern: '(?:\\+?1[-. ]?)?\\(?[0-9]{3}\\)?[-. ]?[0-9]{3}[-. ]?[0-9]{4}',
      enabled: true,
      description: 'Matches US phone number formats'
    },
    {
      id: '3',
      name: 'Dollar Amounts',
      type: 'amount',
      pattern: '\\$[\\d,]+(?:\\.[\\d]{2})?',
      enabled: false,
      description: 'Currency amounts in USD'
    }
  ]);

  return (
    <div className="p-6">
      <ExtractionRules 
        rules={rules}
        onRulesChange={setRules}
      />
    </div>
  );
}