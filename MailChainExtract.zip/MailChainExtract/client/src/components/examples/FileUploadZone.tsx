import FileUploadZone from '../FileUploadZone';

export default function FileUploadZoneExample() {
  const handleFilesSelected = (files: File[]) => {
    console.log('Files selected:', files.map(f => f.name));
  };

  return (
    <div className="p-6 max-w-2xl">
      <FileUploadZone 
        onFilesSelected={handleFilesSelected}
        acceptedTypes={['.eml', '.msg', '.txt']}
        maxFiles={10}
        isProcessing={false}
      />
    </div>
  );
}