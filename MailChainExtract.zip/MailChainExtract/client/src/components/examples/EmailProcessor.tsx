import { useState } from 'react';
import EmailProcessor from '../EmailProcessor';
import type { EmailProcessingResult } from '@shared/schema';

export default function EmailProcessorExample() {
  // //todo: remove mock functionality - mock files for demo
  const mockFiles = [
    new File(['email content 1'], 'meeting-notes.eml', { type: 'message/rfc822' }),
    new File(['email content 2'], 'client-feedback.msg', { type: 'application/vnd.ms-outlook' }),
    new File(['email content 3'], 'project-update.eml', { type: 'message/rfc822' })
  ];

  const handleProcessingComplete = (results: EmailProcessingResult[]) => {
    console.log('Processing completed:', results);
  };

  return (
    <div className="p-6 max-w-4xl">
      <EmailProcessor
        files={mockFiles}
        onProcessingComplete={handleProcessingComplete}
        isProcessing={false}
        processingProgress={0}
      />
    </div>
  );
}