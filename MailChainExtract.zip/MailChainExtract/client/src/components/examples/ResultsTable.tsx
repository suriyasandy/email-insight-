import ResultsTable from '../ResultsTable';
import type { EmailProcessingResult } from '@shared/schema';

export default function ResultsTableExample() {
  // //todo: remove mock functionality - mock results for demo
  const mockResults: EmailProcessingResult[] = [
    {
      id: '1',
      fileName: 'client-meeting.eml',
      fileSize: 15420,
      processedAt: '2024-01-15T10:30:00Z',
      metadata: {
        sender: 'john.smith@company.com',
        recipient: ['team@company.com'],
        subject: 'Client Meeting Follow-up',
        date: '2024-01-15T09:00:00Z'
      },
      extractedAttributes: [
        {
          id: '1-1',
          type: 'email',
          value: 'client@bigcorp.com',
          confidence: 0.95,
          position: { start: 120, end: 139 },
          context: 'Please reach out to client@bigcorp.com for the proposal'
        },
        {
          id: '1-2',
          type: 'phone',
          value: '+1 (555) 123-4567',
          confidence: 0.89,
          position: { start: 245, end: 261 },
          context: 'Contact number: +1 (555) 123-4567 during business hours'
        },
        {
          id: '1-3',
          type: 'amount',
          value: '$45,000',
          confidence: 0.92,
          position: { start: 340, end: 347 },
          context: 'The project budget is $45,000 for Q1'
        }
      ],
      rawContent: 'Mock email content...'
    },
    {
      id: '2',
      fileName: 'vendor-invoice.msg',
      fileSize: 8920,
      processedAt: '2024-01-15T10:35:00Z',
      metadata: {
        sender: 'billing@vendor.com',
        recipient: ['accounting@company.com'],
        subject: 'Invoice #INV-2024-001',
        date: '2024-01-14T14:22:00Z'
      },
      extractedAttributes: [
        {
          id: '2-1',
          type: 'amount',
          value: '$2,450.00',
          confidence: 0.98,
          position: { start: 180, end: 189 },
          context: 'Total amount due: $2,450.00 by January 30th'
        },
        {
          id: '2-2',
          type: 'date',
          value: 'January 30, 2024',
          confidence: 0.94,
          position: { start: 200, end: 216 },
          context: 'Payment due date: January 30, 2024'
        },
        {
          id: '2-3',
          type: 'address',
          value: '123 Business Ave, Suite 100, New York, NY 10001',
          confidence: 0.87,
          position: { start: 50, end: 97 },
          context: 'Billing address: 123 Business Ave, Suite 100, New York, NY 10001'
        }
      ],
      rawContent: 'Mock invoice content...'
    }
  ];

  const handleExport = (format: 'csv' | 'json') => {
    console.log('Exporting results as:', format);
  };

  return (
    <div className="p-6">
      <ResultsTable 
        results={mockResults}
        onExport={handleExport}
      />
    </div>
  );
}