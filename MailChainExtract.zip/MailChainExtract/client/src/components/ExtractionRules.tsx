import { useState } from 'react';
import { Plus, Edit, Trash2, Eye, EyeOff, TestTube } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Separator } from '@/components/ui/separator';
import type { ExtractionRule } from '@shared/schema';

interface ExtractionRulesProps {
  rules: ExtractionRule[];
  onRulesChange: (rules: ExtractionRule[]) => void;
}

interface RuleFormData {
  name: string;
  type: ExtractionRule['type'];
  pattern: string;
  description: string;
  enabled: boolean;
}

const defaultPatterns = {
  email: /[\w\.-]+@[\w\.-]+\.[\w]+/g,
  phone: /(?:\+?1[-. ]?)?\(?[0-9]{3}\)?[-. ]?[0-9]{3}[-. ]?[0-9]{4}/g,
  date: /\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\w+\s+\d{1,2},?\s+\d{4})\b/g,
  amount: /\$[\d,]+(?:\.\d{2})?|\b\d+(?:,\d{3})*(?:\.\d{2})?\s*(?:dollars?|USD)\b/g,
  name: /\b[A-Z][a-z]+(?:\s[A-Z][a-z]+)*\b/g,
  address: /\d+\s[A-Za-z\s,]+\d{5}(?:-\d{4})?/g,
  custom: ''
};

export default function ExtractionRules({ rules, onRulesChange }: ExtractionRulesProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<ExtractionRule | null>(null);
  const [formData, setFormData] = useState<RuleFormData>({
    name: '',
    type: 'custom',
    pattern: '',
    description: '',
    enabled: true
  });
  const [testString, setTestString] = useState('');
  const [testResults, setTestResults] = useState<string[]>([]);

  const resetForm = () => {
    setFormData({
      name: '',
      type: 'custom',
      pattern: '',
      description: '',
      enabled: true
    });
    setEditingRule(null);
    setTestString('');
    setTestResults([]);
  };

  const openEditDialog = (rule: ExtractionRule) => {
    setEditingRule(rule);
    setFormData({
      name: rule.name,
      type: rule.type,
      pattern: rule.pattern,
      description: rule.description || '',
      enabled: rule.enabled
    });
    setIsDialogOpen(true);
  };

  const handleTypeChange = (type: ExtractionRule['type']) => {
    setFormData(prev => ({
      ...prev,
      type,
      pattern: type === 'custom' ? '' : defaultPatterns[type].toString().slice(1, -2) // Remove regex delimiters
    }));
  };

  const testPattern = () => {
    if (!formData.pattern || !testString) {
      setTestResults([]);
      return;
    }

    try {
      const regex = new RegExp(formData.pattern, 'g');
      const matches = testString.match(regex) || [];
      setTestResults(matches);
      console.log('Pattern test results:', matches);
    } catch (error) {
      console.error('Invalid regex pattern:', error);
      setTestResults(['Invalid pattern']);
    }
  };

  const handleSave = () => {
    if (!formData.name || !formData.pattern) {
      console.log('Name and pattern are required');
      return;
    }

    const rule: ExtractionRule = {
      id: editingRule?.id || Math.random().toString(36).substr(2, 9),
      name: formData.name,
      type: formData.type,
      pattern: formData.pattern,
      description: formData.description,
      enabled: formData.enabled
    };

    if (editingRule) {
      const updatedRules = rules.map(r => r.id === editingRule.id ? rule : r);
      onRulesChange(updatedRules);
    } else {
      onRulesChange([...rules, rule]);
    }

    setIsDialogOpen(false);
    resetForm();
  };

  const handleDelete = (ruleId: string) => {
    const updatedRules = rules.filter(r => r.id !== ruleId);
    onRulesChange(updatedRules);
  };

  const toggleRule = (ruleId: string) => {
    const updatedRules = rules.map(rule => 
      rule.id === ruleId ? { ...rule, enabled: !rule.enabled } : rule
    );
    onRulesChange(updatedRules);
  };

  const getTypeColor = (type: ExtractionRule['type']) => {
    const colors = {
      email: 'bg-blue-100 text-blue-800',
      phone: 'bg-green-100 text-green-800',
      date: 'bg-purple-100 text-purple-800',
      amount: 'bg-yellow-100 text-yellow-800',
      name: 'bg-pink-100 text-pink-800',
      address: 'bg-orange-100 text-orange-800',
      custom: 'bg-gray-100 text-gray-800'
    };
    return colors[type];
  };

  return (
    <Card data-testid="extraction-rules">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div>
          <CardTitle className="text-lg">Extraction Rules</CardTitle>
          <p className="text-sm text-muted-foreground mt-1">
            Configure regex patterns to extract specific attributes from emails
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm} data-testid="button-add-rule">
              <Plus className="h-4 w-4 mr-2" />
              Add Rule
            </Button>
          </DialogTrigger>
          
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingRule ? 'Edit Extraction Rule' : 'Create New Extraction Rule'}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-6 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="rule-name">Rule Name</Label>
                  <Input
                    id="rule-name"
                    placeholder="e.g., Company Email Addresses"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    data-testid="input-rule-name"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="rule-type">Type</Label>
                  <Select value={formData.type} onValueChange={handleTypeChange}>
                    <SelectTrigger data-testid="select-rule-type">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">Email</SelectItem>
                      <SelectItem value="phone">Phone</SelectItem>
                      <SelectItem value="date">Date</SelectItem>
                      <SelectItem value="amount">Amount</SelectItem>
                      <SelectItem value="name">Name</SelectItem>
                      <SelectItem value="address">Address</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="rule-pattern">Regex Pattern</Label>
                <Textarea
                  id="rule-pattern"
                  placeholder="Enter regex pattern..."
                  value={formData.pattern}
                  onChange={(e) => setFormData(prev => ({ ...prev, pattern: e.target.value }))}
                  className="font-mono text-sm"
                  rows={3}
                  data-testid="input-rule-pattern"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="rule-description">Description (Optional)</Label>
                <Input
                  id="rule-description"
                  placeholder="Describe what this rule extracts..."
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  data-testid="input-rule-description"
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.enabled}
                  onCheckedChange={(enabled) => setFormData(prev => ({ ...prev, enabled }))}
                  data-testid="switch-rule-enabled"
                />
                <Label>Enable this rule</Label>
              </div>
              
              <Separator />
              
              {/* Pattern Testing */}
              <div className="space-y-4">
                <h4 className="font-medium text-sm">Test Pattern</h4>
                
                <div className="space-y-2">
                  <Label htmlFor="test-string">Test String</Label>
                  <Textarea
                    id="test-string"
                    placeholder="Enter text to test your pattern against..."
                    value={testString}
                    onChange={(e) => setTestString(e.target.value)}
                    rows={3}
                    data-testid="input-test-string"
                  />
                </div>
                
                <Button
                  type="button"
                  variant="outline"
                  onClick={testPattern}
                  disabled={!formData.pattern || !testString}
                  data-testid="button-test-pattern"
                >
                  <TestTube className="h-4 w-4 mr-2" />
                  Test Pattern
                </Button>
                
                {testResults.length > 0 && (
                  <div className="space-y-2">
                    <Label>Matches Found ({testResults.length})</Label>
                    <div className="p-3 rounded-md bg-muted font-mono text-sm max-h-32 overflow-y-auto" data-testid="test-results">
                      {testResults.map((match, index) => (
                        <div key={index} className="py-1">
                          {match}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsDialogOpen(false);
                    resetForm();
                  }}
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
                <Button onClick={handleSave} data-testid="button-save-rule">
                  {editingRule ? 'Update Rule' : 'Create Rule'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      
      <Separator />
      
      <CardContent className="p-0">
        {rules.length === 0 ? (
          <div className="text-center py-8" data-testid="no-rules">
            <p className="text-muted-foreground">No extraction rules configured</p>
            <p className="text-sm text-muted-foreground mt-2">
              Add rules to extract specific attributes from your email files
            </p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[60px]">Status</TableHead>
                <TableHead className="min-w-[150px]">Name</TableHead>
                <TableHead className="w-[100px]">Type</TableHead>
                <TableHead className="min-w-[200px]">Pattern</TableHead>
                <TableHead className="min-w-[200px]">Description</TableHead>
                <TableHead className="w-[120px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rules.map((rule) => (
                <TableRow key={rule.id} className="hover-elevate" data-testid={`row-rule-${rule.id}`}>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleRule(rule.id)}
                      className="h-8 w-8 p-0"
                      data-testid={`button-toggle-${rule.id}`}
                    >
                      {rule.enabled ? (
                        <Eye className="h-4 w-4 text-chart-1" />
                      ) : (
                        <EyeOff className="h-4 w-4 text-muted-foreground" />
                      )}
                    </Button>
                  </TableCell>
                  
                  <TableCell className="font-medium" data-testid={`text-rule-name-${rule.id}`}>
                    {rule.name}
                  </TableCell>
                  
                  <TableCell>
                    <Badge 
                      variant="secondary"
                      className={`text-xs ${getTypeColor(rule.type)}`}
                      data-testid={`badge-rule-type-${rule.id}`}
                    >
                      {rule.type}
                    </Badge>
                  </TableCell>
                  
                  <TableCell>
                    <code className="text-xs bg-muted px-2 py-1 rounded break-all" data-testid={`text-rule-pattern-${rule.id}`}>
                      {rule.pattern.length > 40 ? `${rule.pattern.substring(0, 40)}...` : rule.pattern}
                    </code>
                  </TableCell>
                  
                  <TableCell>
                    <span className="text-sm text-muted-foreground" data-testid={`text-rule-desc-${rule.id}`}>
                      {rule.description || 'No description'}
                    </span>
                  </TableCell>
                  
                  <TableCell>
                    <div className="flex space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openEditDialog(rule)}
                        className="h-8 w-8 p-0"
                        data-testid={`button-edit-${rule.id}`}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(rule.id)}
                        className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                        data-testid={`button-delete-${rule.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}