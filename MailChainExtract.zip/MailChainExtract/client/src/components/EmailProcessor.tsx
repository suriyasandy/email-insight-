import { useState } from 'react';
import { Play, Square, RotateCcw, Settings, FileText, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import type { EmailProcessingResult } from '@shared/schema';

interface EmailProcessorProps {
  files: File[];
  onProcessingComplete: (results: EmailProcessingResult[]) => void;
  isProcessing?: boolean;
  processingProgress?: number;
}

interface ProcessingStats {
  totalFiles: number;
  processedFiles: number;
  extractedAttributes: number;
  processingTime: number;
}

export default function EmailProcessor({
  files,
  onProcessingComplete,
  isProcessing = false,
  processingProgress = 0
}: EmailProcessorProps) {
  const [stats, setStats] = useState<ProcessingStats>({
    totalFiles: 0,
    processedFiles: 0,
    extractedAttributes: 0,
    processingTime: 0
  });
  const [currentFile, setCurrentFile] = useState<string>('');

  const startProcessing = () => {
    console.log('Processing started for', files.length, 'files');
    setStats({
      totalFiles: files.length,
      processedFiles: 0,
      extractedAttributes: 0,
      processingTime: 0
    });
    
    // //todo: remove mock functionality - simulate processing
    files.forEach((file, index) => {
      setTimeout(() => {
        setCurrentFile(file.name);
        setStats(prev => ({
          ...prev,
          processedFiles: index + 1,
          extractedAttributes: prev.extractedAttributes + Math.floor(Math.random() * 15) + 5,
          processingTime: prev.processingTime + Math.floor(Math.random() * 2000) + 500
        }));
        
        if (index === files.length - 1) {
          // //todo: remove mock functionality - mock results
          const mockResults: EmailProcessingResult[] = files.map(file => ({
            id: Math.random().toString(36).substr(2, 9),
            fileName: file.name,
            fileSize: file.size,
            processedAt: new Date().toISOString(),
            metadata: {
              sender: 'john@example.com',
              recipient: ['jane@example.com'],
              subject: 'Re: Project Update',
              date: new Date().toISOString()
            },
            extractedAttributes: [
              {
                id: '1',
                type: 'email',
                value: 'contact@company.com',
                confidence: 0.95,
                position: { start: 100, end: 118 },
                context: 'Please contact us at contact@company.com'
              },
              {
                id: '2',
                type: 'phone',
                value: '+1 (555) 123-4567',
                confidence: 0.89,
                position: { start: 250, end: 266 },
                context: 'Call us at +1 (555) 123-4567 for support'
              }
            ],
            rawContent: 'Mock email content...'
          }));
          
          setTimeout(() => onProcessingComplete(mockResults), 500);
        }
      }, (index + 1) * 1000);
    });
  };

  const stopProcessing = () => {
    console.log('Processing stopped');
  };

  const resetProcessing = () => {
    console.log('Processing reset');
    setStats({ totalFiles: 0, processedFiles: 0, extractedAttributes: 0, processingTime: 0 });
    setCurrentFile('');
  };

  return (
    <Card data-testid="email-processor">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div>
          <CardTitle className="text-lg">Email Processing</CardTitle>
          <p className="text-sm text-muted-foreground mt-1">
            Extract attributes from {files.length} email files using rule-based patterns
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => console.log('Configure extraction rules')}
            data-testid="button-configure"
          >
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      
      <Separator />
      
      <CardContent className="pt-6">
        <div className="space-y-6">
          {/* Processing Controls */}
          <div className="flex items-center space-x-3">
            <Button
              onClick={startProcessing}
              disabled={isProcessing || files.length === 0}
              data-testid="button-start-processing"
            >
              <Play className="h-4 w-4 mr-2" />
              Start Processing
            </Button>
            
            <Button
              variant="outline"
              onClick={stopProcessing}
              disabled={!isProcessing}
              data-testid="button-stop-processing"
            >
              <Square className="h-4 w-4 mr-2" />
              Stop
            </Button>
            
            <Button
              variant="ghost"
              onClick={resetProcessing}
              data-testid="button-reset-processing"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
          </div>

          {/* Processing Progress */}
          {(isProcessing || stats.processedFiles > 0) && (
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Progress</span>
                  <span className="font-medium">
                    {stats.processedFiles} / {stats.totalFiles} files
                  </span>
                </div>
                <Progress 
                  value={stats.totalFiles > 0 ? (stats.processedFiles / stats.totalFiles) * 100 : 0} 
                  className="h-2"
                  data-testid="progress-processing"
                />
              </div>
              
              {currentFile && (
                <div className="flex items-center space-x-2 text-sm">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Processing:</span>
                  <span className="font-medium" data-testid="text-current-file">{currentFile}</span>
                </div>
              )}
            </div>
          )}

          {/* Processing Statistics */}
          {stats.processedFiles > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-3 rounded-lg bg-muted/50">
                <FileText className="h-5 w-5 mx-auto mb-1 text-muted-foreground" />
                <div className="text-lg font-semibold" data-testid="stat-files">{stats.processedFiles}</div>
                <div className="text-xs text-muted-foreground">Files Processed</div>
              </div>
              
              <div className="text-center p-3 rounded-lg bg-muted/50">
                <CheckCircle className="h-5 w-5 mx-auto mb-1 text-chart-1" />
                <div className="text-lg font-semibold" data-testid="stat-attributes">{stats.extractedAttributes}</div>
                <div className="text-xs text-muted-foreground">Attributes Found</div>
              </div>
              
              <div className="text-center p-3 rounded-lg bg-muted/50">
                <Clock className="h-5 w-5 mx-auto mb-1 text-muted-foreground" />
                <div className="text-lg font-semibold" data-testid="stat-time">{(stats.processingTime / 1000).toFixed(1)}s</div>
                <div className="text-xs text-muted-foreground">Processing Time</div>
              </div>
              
              <div className="text-center p-3 rounded-lg bg-muted/50">
                <AlertCircle className="h-5 w-5 mx-auto mb-1 text-muted-foreground" />
                <div className="text-lg font-semibold" data-testid="stat-confidence">94%</div>
                <div className="text-xs text-muted-foreground">Avg Confidence</div>
              </div>
            </div>
          )}

          {/* File Status */}
          {files.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Files Queue</h4>
              <div className="space-y-1">
                {files.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-2 rounded-md bg-muted/30">
                    <div className="flex items-center space-x-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{file.name}</span>
                    </div>
                    <Badge 
                      variant={index < stats.processedFiles ? "default" : "secondary"}
                      className="text-xs"
                      data-testid={`status-file-${index}`}
                    >
                      {index < stats.processedFiles ? "Completed" : "Pending"}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}