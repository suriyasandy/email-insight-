import streamlit as st
import pandas as pd
import json
import io
import base64
from financial_ner import FinancialNERExtractor
from utils import process_uploaded_file, export_to_json, export_to_csv, display_entity_metrics

# Configure page
st.set_page_config(
    page_title="Financial Entity Extraction",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'extractor' not in st.session_state:
    st.session_state.extractor = FinancialNERExtractor()

def main():
    st.title("💰 Financial Entity Extraction")
    st.markdown("Extract financial entities from documents using offline spaCy NER model")
    
    # Sidebar for model information and settings
    with st.sidebar:
        st.header("📊 Model Information")
        
        # Display model status
        model_status = st.session_state.extractor.get_model_status()
        if model_status['loaded']:
            st.success(f"✅ Model loaded: {model_status['name']}")
            st.info(f"Entities: {', '.join(model_status['entities'])}")
        else:
            st.error("❌ Model not available")
            st.warning("Using rule-based extraction as fallback")
        
        st.header("⚙️ Settings")
        confidence_threshold = st.slider(
            "Confidence Threshold",
            min_value=0.0,
            max_value=1.0,
            value=0.5,
            step=0.1,
            help="Minimum confidence score for entity extraction"
        )
        
        show_metrics = st.checkbox("Show Performance Metrics", value=True)
        highlight_entities = st.checkbox("Highlight Entities in Text", value=True)
    
    # Main content area
    tab1, tab2, tab3 = st.tabs(["📄 File Upload", "✏️ Direct Input", "📈 Analytics"])
    
    with tab1:
        st.header("Upload Financial Documents")
        st.markdown("Support formats: TXT, CSV, and other text files")
        
        uploaded_files = st.file_uploader(
            "Choose files",
            accept_multiple_files=True,
            type=['txt', 'csv', 'log', 'msg'],
            help="Upload financial documents, emails, trade logs, or reports"
        )
        
        if uploaded_files:
            for uploaded_file in uploaded_files:
                with st.expander(f"📁 {uploaded_file.name}", expanded=True):
                    try:
                        text_content = process_uploaded_file(uploaded_file)
                        
                        if text_content:
                            st.text_area(
                                "File Content Preview",
                                text_content[:500] + "..." if len(text_content) > 500 else text_content,
                                height=100,
                                key=f"preview_{uploaded_file.name}"
                            )
                            
                            if st.button(f"Extract Entities from {uploaded_file.name}", key=f"extract_{uploaded_file.name}"):
                                process_text_extraction(text_content, uploaded_file.name, confidence_threshold, highlight_entities, show_metrics)
                        else:
                            st.error("Could not read file content")
                    
                    except Exception as e:
                        st.error(f"Error processing file: {str(e)}")
    
    with tab2:
        st.header("Direct Text Input")
        st.markdown("Enter or paste financial text directly")
        
        # Sample text for demonstration
        sample_text = """Trade ID TRD-2025-001 has been executed with a notional amount of 5.2M USD. 
        The counterparty is Goldman Sachs and the legal entity is JPMorgan Chase. 
        Current PnL shows +125,000 USD profit. CVA adjustment of 0.03% applied. 
        Settlement date: 2025-09-20."""
        
        text_input = st.text_area(
            "Enter financial text",
            height=150,
            placeholder="Enter financial text here...",
            help="Example: Trade reports, emails, transaction logs"
        )
        
        col1, col2 = st.columns([1, 1])
        with col1:
            if st.button("📝 Use Sample Text"):
                st.session_state.sample_used = True
                text_input = sample_text
                st.rerun()
        
        with col2:
            if st.button("🔍 Extract Entities", disabled=not text_input):
                process_text_extraction(text_input, "Direct Input", confidence_threshold, highlight_entities, show_metrics)
    
    with tab3:
        st.header("Analytics Dashboard")
        
        if 'extraction_results' in st.session_state:
            results = st.session_state.extraction_results
            
            # Entity distribution
            entity_counts = {}
            for result in results:
                for entity in result['entities']:
                    entity_type = entity['label']
                    entity_counts[entity_type] = entity_counts.get(entity_type, 0) + 1
            
            if entity_counts:
                st.subheader("📊 Entity Distribution")
                df_counts = pd.DataFrame.from_records(list(entity_counts.items()), columns=['Entity Type', 'Count'])
                st.bar_chart(df_counts.set_index('Entity Type'))
                
                # Entity details table
                st.subheader("📋 All Extracted Entities")
                all_entities = []
                for result in results:
                    for entity in result['entities']:
                        all_entities.append({
                            'Source': result['source'],
                            'Text': entity['text'],
                            'Label': entity['label'],
                            'Start': entity['start'],
                            'End': entity['end'],
                            'Confidence': entity.get('confidence', 'N/A')
                        })
                
                if all_entities:
                    df_entities = pd.DataFrame(all_entities)
                    st.dataframe(df_entities, use_container_width=True)
            else:
                st.info("No extraction results available. Process some text first.")
        else:
            st.info("No extraction results available. Process some text first.")

def process_text_extraction(text, source_name, confidence_threshold, highlight_entities, show_metrics):
    """Process text extraction and display results"""
    with st.spinner("Extracting entities..."):
        try:
            # Extract entities
            result = st.session_state.extractor.extract_entities(text, confidence_threshold)
            
            # Store results in session state
            if 'extraction_results' not in st.session_state:
                st.session_state.extraction_results = []
            
            extraction_data = {
                'source': source_name,
                'text': text,
                'entities': result['entities'],
                'metrics': result.get('metrics', {})
            }
            
            st.session_state.extraction_results.append(extraction_data)
            
            # Display results
            st.success(f"✅ Extracted {len(result['entities'])} entities")
            
            # Show entities in structured format
            if result['entities']:
                st.subheader("📋 Extracted Entities")
                
                # Group entities by type
                entities_by_type = {}
                for entity in result['entities']:
                    entity_type = entity['label']
                    if entity_type not in entities_by_type:
                        entities_by_type[entity_type] = []
                    entities_by_type[entity_type].append(entity)
                
                # Display entities by type
                for entity_type, entities in entities_by_type.items():
                    with st.expander(f"{entity_type} ({len(entities)} found)", expanded=True):
                        for entity in entities:
                            col1, col2, col3 = st.columns([3, 1, 1])
                            with col1:
                                st.write(f"**{entity['text']}**")
                            with col2:
                                st.write(f"Pos: {entity['start']}-{entity['end']}")
                            with col3:
                                confidence = entity.get('confidence', 'N/A')
                                st.write(f"Conf: {confidence}")
                
                # Highlight entities in original text
                if highlight_entities:
                    st.subheader("🎨 Text with Highlighted Entities")
                    highlighted_text = st.session_state.extractor.highlight_entities_html(text, result['entities'])
                    st.markdown(highlighted_text, unsafe_allow_html=True)
                
                # Export options
                st.subheader("💾 Export Results")
                col1, col2 = st.columns(2)
                
                with col1:
                    if st.button("📄 Export as JSON"):
                        json_data = export_to_json(extraction_data)
                        st.download_button(
                            label="📥 Download JSON",
                            data=json_data,
                            file_name=f"entities_{source_name.lower().replace(' ', '_')}.json",
                            mime="application/json"
                        )
                
                with col2:
                    if st.button("📊 Export as CSV"):
                        csv_data = export_to_csv(extraction_data)
                        st.download_button(
                            label="📥 Download CSV",
                            data=csv_data,
                            file_name=f"entities_{source_name.lower().replace(' ', '_')}.csv",
                            mime="text/csv"
                        )
                
                # Show performance metrics
                if show_metrics and result.get('metrics'):
                    st.subheader("📊 Performance Metrics")
                    display_entity_metrics(result['metrics'])
            
            else:
                st.warning("No entities found in the text")
                
        except Exception as e:
            st.error(f"Error during extraction: {str(e)}")

if __name__ == "__main__":
    main()
