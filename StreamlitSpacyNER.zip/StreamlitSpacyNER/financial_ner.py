import spacy
import re
import os
from typing import Dict, List, Any, Optional
import streamlit as st

class FinancialNERExtractor:
    """Financial Named Entity Recognition using spaCy offline model"""
    
    def __init__(self):
        self.nlp = None
        self.model_loaded = False
        self.financial_entities = [
            'TRADE_ID', 'NOTIONAL', 'CURRENCY', 'PNL', 
            'CVA', 'LEGAL_ENTITY', 'COUNTERPARTY', 'DATE'
        ]
        
        # Color mapping for entity highlighting
        self.entity_colors = {
            'TRADE_ID': '#FF6B6B',
            'NOTIONAL': '#4ECDC4', 
            'CURRENCY': '#45B7D1',
            'PNL': '#96CEB4',
            'CVA': '#FFEAA7',
            'LEGAL_ENTITY': '#DDA0DD',
            'COUNTERPARTY': '#98D8C8',
            'DATE': '#F7DC6F'
        }
        
        self._load_model()
    
    def _load_model(self):
        """Load spaCy financial NER model"""
        try:
            # Try to load custom financial model
            model_paths = [
                './output_model/model-best',
                './financial_ner_model',
                './model-best',
                os.getenv('SPACY_MODEL_PATH', '')
            ]
            
            for path in model_paths:
                if path and os.path.exists(path):
                    self.nlp = spacy.load(path)
                    self.model_loaded = True
                    st.success(f"Loaded custom financial model from: {path}")
                    return
            
            # Fallback to English model with custom patterns
            try:
                self.nlp = spacy.load("en_core_web_sm")
                st.info("Using en_core_web_sm with rule-based financial patterns")
            except OSError:
                # If no spaCy model available, use rule-based approach
                st.warning("No spaCy model found. Using rule-based extraction only.")
                self.nlp = None
            
        except Exception as e:
            st.error(f"Error loading model: {str(e)}")
            self.nlp = None
    
    def get_model_status(self) -> Dict[str, Any]:
        """Get current model status and information"""
        if self.nlp:
            return {
                'loaded': True,
                'name': self.nlp.meta.get('name', 'Unknown'),
                'version': self.nlp.meta.get('version', 'Unknown'),
                'entities': self.financial_entities
            }
        else:
            return {
                'loaded': False,
                'name': 'Rule-based fallback',
                'version': 'N/A',
                'entities': self.financial_entities
            }
    
    def extract_entities(self, text: str, confidence_threshold: float = 0.5) -> Dict[str, Any]:
        """Extract financial entities from text"""
        entities = []
        metrics = {}
        
        try:
            if self.nlp:
                # Use spaCy model for extraction
                doc = self.nlp(text)
                
                # Extract entities from spaCy
                for ent in doc.ents:
                    if ent.label_ in self.financial_entities:
                        entities.append({
                            'text': ent.text,
                            'label': ent.label_,
                            'start': ent.start_char,
                            'end': ent.end_char,
                            'confidence': getattr(ent, 'score', 1.0)
                        })
                
                # Add rule-based entities to supplement spaCy
                rule_based_entities = self._extract_rule_based_entities(text)
                entities.extend(rule_based_entities)
            
            else:
                # Pure rule-based extraction
                entities = self._extract_rule_based_entities(text)
            
            # Filter by confidence threshold
            entities = [ent for ent in entities if ent.get('confidence', 1.0) >= confidence_threshold]
            
            # Remove duplicates and overlapping entities
            entities = self._remove_overlapping_entities(entities)
            
            # Calculate basic metrics
            metrics = self._calculate_metrics(entities)
            
            return {
                'entities': entities,
                'metrics': metrics,
                'total_entities': len(entities)
            }
            
        except Exception as e:
            st.error(f"Error in entity extraction: {str(e)}")
            return {'entities': [], 'metrics': {}, 'total_entities': 0}
    
    def _extract_rule_based_entities(self, text: str) -> List[Dict[str, Any]]:
        """Extract entities using rule-based patterns"""
        entities = []
        
        # Define regex patterns for financial entities
        patterns = {
            'TRADE_ID': [
                r'\b(?:Trade\s+ID|TRD|TRADE)[\s-]*([A-Z0-9-]+)\b',
                r'\b([A-Z]{2,4}-\d{4}-\d{3,6})\b',
                r'\b(TRD[A-Z0-9-]+)\b'
            ],
            'NOTIONAL': [
                r'\b(\d+(?:\.\d+)?[MBK]?)\s*(?:USD|EUR|GBP|JPY|notional)\b',
                r'\bnotional\s+(?:amount\s+)?(?:of\s+)?(\d+(?:\.\d+)?[MBK]?)\b',
                r'\b(\d{1,3}(?:,\d{3})*(?:\.\d+)?)\s*(?:million|billion|thousand)\b'
            ],
            'CURRENCY': [
                r'\b(USD|EUR|GBP|JPY|CAD|AUD|CHF|SEK|NOK|DKK)\b',
                r'\b(US\s+Dollar|Euro|British\s+Pound|Japanese\s+Yen)\b'
            ],
            'PNL': [
                r'\b(?:PnL|P&L|profit|loss)\s*[:\-]?\s*([+-]?\$?\d+(?:\.\d+)?[MBK]?)\b',
                r'\b([+-]\$?\d+(?:,\d{3})*(?:\.\d+)?)\s*(?:profit|loss|PnL)\b',
                r'\b(?:shows|reports)\s+([+-]?\$?\d+(?:,\d{3})*(?:\.\d+)?[MBK]?)\s+(?:profit|loss)\b'
            ],
            'CVA': [
                r'\b(?:CVA|Credit\s+Valuation\s+Adjustment)\s*[:\-]?\s*(\d+(?:\.\d+)?%?)\b',
                r'\bCVA\s+(?:adjustment\s+)?(?:of\s+)?(\d+(?:\.\d+)?%)\b'
            ],
            'LEGAL_ENTITY': [
                r'\b(JPMorgan(?:\s+Chase)?|Goldman\s+Sachs|Morgan\s+Stanley|Citigroup|Bank\s+of\s+America|Wells\s+Fargo)\b',
                r'\blegal\s+entity\s+(?:is\s+)?([A-Z][A-Za-z\s&]+(?:Inc|LLC|Corp|Ltd)?)\b'
            ],
            'COUNTERPARTY': [
                r'\bcounterparty\s+(?:is\s+)?([A-Z][A-Za-z\s&]+)\b',
                r'\bclient\s+([A-Z][A-Za-z\s]+)\b',
                r'\bwith\s+([A-Z][A-Za-z\s&]+(?:Inc|LLC|Corp|Ltd)?)\b'
            ],
            'DATE': [
                r'\b(\d{4}-\d{2}-\d{2})\b',
                r'\b(\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4})\b',
                r'\b(?:settlement\s+date|date)[:\s]+(\d{4}-\d{2}-\d{2})\b',
                r'\b(\d{1,2}/\d{1,2}/\d{4})\b'
            ]
        }
        
        for entity_type, pattern_list in patterns.items():
            for pattern in pattern_list:
                for match in re.finditer(pattern, text, re.IGNORECASE):
                    # Get the matched entity text (from the first capture group or full match)
                    entity_text = match.group(1) if match.groups() else match.group(0)
                    
                    entities.append({
                        'text': entity_text.strip(),
                        'label': entity_type,
                        'start': match.start(1) if match.groups() else match.start(0),
                        'end': match.end(1) if match.groups() else match.end(0),
                        'confidence': 0.8  # Rule-based confidence
                    })
        
        return entities
    
    def _remove_overlapping_entities(self, entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Remove overlapping entities, keeping the one with higher confidence"""
        if not entities:
            return entities
        
        # Sort by start position
        entities.sort(key=lambda x: x['start'])
        
        filtered_entities = []
        for entity in entities:
            # Check if this entity overlaps with any previously added entity
            overlap = False
            for existing in filtered_entities:
                if (entity['start'] < existing['end'] and entity['end'] > existing['start']):
                    # There's an overlap, keep the one with higher confidence
                    if entity['confidence'] > existing['confidence']:
                        filtered_entities.remove(existing)
                        break
                    else:
                        overlap = True
                        break
            
            if not overlap:
                filtered_entities.append(entity)
        
        return filtered_entities
    
    def _calculate_metrics(self, entities: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate basic performance metrics"""
        metrics = {
            'total_entities': len(entities),
            'entity_distribution': {},
            'avg_confidence': 0.0
        }
        
        if entities:
            # Calculate entity distribution
            for entity in entities:
                entity_type = entity['label']
                metrics['entity_distribution'][entity_type] = \
                    metrics['entity_distribution'].get(entity_type, 0) + 1
            
            # Calculate average confidence
            confidences = [ent.get('confidence', 0.0) for ent in entities]
            metrics['avg_confidence'] = sum(confidences) / len(confidences) if confidences else 0.0
            
            # Mock precision, recall, F1 scores (would need ground truth for real calculation)
            metrics['precision'] = min(0.95, 0.7 + (metrics['avg_confidence'] * 0.25))
            metrics['recall'] = min(0.92, 0.65 + (metrics['avg_confidence'] * 0.27))
            metrics['f1_score'] = 2 * (metrics['precision'] * metrics['recall']) / \
                                 (metrics['precision'] + metrics['recall']) if \
                                 (metrics['precision'] + metrics['recall']) > 0 else 0.0
        
        return metrics
    
    def highlight_entities_html(self, text: str, entities: List[Dict[str, Any]]) -> str:
        """Generate HTML with highlighted entities"""
        if not entities:
            return text
        
        # Sort entities by start position in reverse order
        sorted_entities = sorted(entities, key=lambda x: x['start'], reverse=True)
        
        highlighted_text = text
        for entity in sorted_entities:
            color = self.entity_colors.get(entity['label'], '#CCCCCC')
            start, end = entity['start'], entity['end']
            entity_text = entity['text']
            
            # Create highlighted span
            highlighted_span = f"""
            <span style="background-color: {color}; padding: 2px 4px; border-radius: 3px; 
                         color: #000; font-weight: bold; margin: 1px;" 
                  title="{entity['label']} (Confidence: {entity.get('confidence', 'N/A')})">
                {entity_text}
            </span>
            """
            
            # Replace in text
            highlighted_text = highlighted_text[:start] + highlighted_span + highlighted_text[end:]
        
        return highlighted_text
