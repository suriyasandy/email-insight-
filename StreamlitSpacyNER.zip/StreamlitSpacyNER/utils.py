import streamlit as st
import pandas as pd
import json
import io
import base64
from typing import Dict, Any, List

def process_uploaded_file(uploaded_file) -> str:
    """Process uploaded file and extract text content"""
    try:
        # Get file extension
        file_extension = uploaded_file.name.split('.')[-1].lower()
        
        if file_extension in ['txt', 'log']:
            # Read text files directly
            return str(uploaded_file.read(), "utf-8")
        
        elif file_extension == 'csv':
            # Read CSV and convert to text representation
            df = pd.read_csv(uploaded_file)
            return df.to_string()
        
        elif file_extension == 'msg':
            # For .msg files, treat as text (would need additional library for proper parsing)
            try:
                return str(uploaded_file.read(), "utf-8", errors='ignore')
            except:
                return str(uploaded_file.read(), "latin-1", errors='ignore')
        
        else:
            # Try to read as text with error handling
            try:
                return str(uploaded_file.read(), "utf-8")
            except UnicodeDecodeError:
                return str(uploaded_file.read(), "latin-1", errors='ignore')
    
    except Exception as e:
        st.error(f"Error reading file: {str(e)}")
        return ""

def export_to_json(extraction_data: Dict[str, Any]) -> str:
    """Export extraction results to JSON format"""
    export_data = {
        'source': extraction_data['source'],
        'extraction_timestamp': pd.Timestamp.now().isoformat(),
        'total_entities': len(extraction_data['entities']),
        'entities': extraction_data['entities'],
        'metrics': extraction_data.get('metrics', {}),
        'original_text': extraction_data['text'][:500] + "..." if len(extraction_data['text']) > 500 else extraction_data['text']
    }
    
    return json.dumps(export_data, indent=2, ensure_ascii=False)

def export_to_csv(extraction_data: Dict[str, Any]) -> str:
    """Export extraction results to CSV format"""
    entities_list = []
    
    for entity in extraction_data['entities']:
        entities_list.append({
            'Source': extraction_data['source'],
            'Entity_Text': entity['text'],
            'Entity_Type': entity['label'],
            'Start_Position': entity['start'],
            'End_Position': entity['end'],
            'Confidence': entity.get('confidence', 'N/A'),
            'Extraction_Time': pd.Timestamp.now().isoformat()
        })
    
    if entities_list:
        df = pd.DataFrame(entities_list)
        return df.to_csv(index=False)
    else:
        return "No entities found"

def display_entity_metrics(metrics: Dict[str, Any]):
    """Display performance metrics in Streamlit"""
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Precision",
            f"{metrics.get('precision', 0):.2f}",
            help="Percentage of predicted entities that are correct"
        )
    
    with col2:
        st.metric(
            "Recall", 
            f"{metrics.get('recall', 0):.2f}",
            help="Percentage of actual entities that were detected"
        )
    
    with col3:
        st.metric(
            "F1-Score",
            f"{metrics.get('f1_score', 0):.2f}",
            help="Balance between precision and recall"
        )
    
    with col4:
        st.metric(
            "Avg Confidence",
            f"{metrics.get('avg_confidence', 0):.2f}",
            help="Average confidence score of extracted entities"
        )
    
    # Entity distribution
    if 'entity_distribution' in metrics and metrics['entity_distribution']:
        st.subheader("Entity Type Distribution")
        
        # Create a bar chart of entity distribution
        entity_dist = metrics['entity_distribution']
        df_dist = pd.DataFrame.from_records(
            list(entity_dist.items()), 
            columns=['Entity Type', 'Count']
        )
        
        st.bar_chart(df_dist.set_index('Entity Type'))
        
        # Display as table as well
        st.dataframe(df_dist, use_container_width=True)

def create_download_link(data: str, filename: str, mime_type: str) -> str:
    """Create a download link for data"""
    b64_data = base64.b64encode(data.encode()).decode()
    href = f'<a href="data:{mime_type};base64,{b64_data}" download="{filename}">📥 Download {filename}</a>'
    return href

def validate_financial_text(text: str) -> Dict[str, Any]:
    """Validate if text contains financial content"""
    financial_keywords = [
        'trade', 'notional', 'currency', 'pnl', 'profit', 'loss',
        'counterparty', 'settlement', 'usd', 'eur', 'gbp', 'jpy',
        'cva', 'legal entity', 'client', 'bank'
    ]
    
    text_lower = text.lower()
    found_keywords = [kw for kw in financial_keywords if kw in text_lower]
    
    return {
        'is_financial': len(found_keywords) > 0,
        'confidence': len(found_keywords) / len(financial_keywords),
        'found_keywords': found_keywords,
        'keyword_count': len(found_keywords)
    }

def format_entity_for_display(entity: Dict[str, Any]) -> str:
    """Format entity information for display"""
    confidence = entity.get('confidence', 'N/A')
    if isinstance(confidence, float):
        confidence = f"{confidence:.2f}"
    
    return f"**{entity['text']}** ({entity['label']}) - Conf: {confidence}"

def get_entity_statistics(entities: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Calculate detailed statistics for extracted entities"""
    if not entities:
        return {}
    
    stats = {
        'total_entities': len(entities),
        'unique_entities': len(set(ent['text'] for ent in entities)),
        'entity_types': len(set(ent['label'] for ent in entities)),
        'avg_entity_length': sum(len(ent['text']) for ent in entities) / len(entities),
        'confidence_distribution': {},
        'entity_type_counts': {}
    }
    
    # Count by entity type
    for entity in entities:
        entity_type = entity['label']
        stats['entity_type_counts'][entity_type] = stats['entity_type_counts'].get(entity_type, 0) + 1
    
    # Confidence distribution
    confidence_ranges = {'High (>0.8)': 0, 'Medium (0.5-0.8)': 0, 'Low (<0.5)': 0}
    for entity in entities:
        conf = entity.get('confidence', 0)
        if conf > 0.8:
            confidence_ranges['High (>0.8)'] += 1
        elif conf > 0.5:
            confidence_ranges['Medium (0.5-0.8)'] += 1
        else:
            confidence_ranges['Low (<0.5)'] += 1
    
    stats['confidence_distribution'] = confidence_ranges
    
    return stats
